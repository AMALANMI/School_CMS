-- Database Backup for School CMS
-- Date: 2026-02-12 05:14:04

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `about_content`;
CREATE TABLE `about_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `stats_students` varchar(50) DEFAULT '1,500+',
  `stats_teachers` varchar(50) DEFAULT '100+',
  `stats_classrooms` varchar(50) DEFAULT '45+',
  `stats_years` varchar(50) DEFAULT '25+',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `about_content` VALUES("1","Little Flower Matric School","About Our Institution","Established with a vision to nurture young minds, Little Flower Matriculation School has been a beacon of academic excellence and holistic development. We believe in providing a nurturing environment where every child can bloom to their fullest potential.","http://localhost:8000/backend/uploads/698ccaa55bc6f8.23552531.png","1,500+","100+","45+","25+","2026-02-11 23:59:59");


DROP TABLE IF EXISTS `academics`;
CREATE TABLE `academics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_level` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied') DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `contact_messages` VALUES("1","Micheal Raj","spamicheal@gmail.com","09791289843","I need Admission for my son "," He is 9 years old , What are the documents need to submit on admission ","read","2026-02-12 03:13:01");
INSERT INTO `contact_messages` VALUES("2","Rajesh kumar","7digitalcare@gmail.com","00987456123","I need Admission for my Daughter","I need admission for my Daughter give details about regarding this  Demo Message ","new","2026-02-12 09:36:36");


DROP TABLE IF EXISTS `correspondent`;
CREATE TABLE `correspondent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `correspondent` VALUES("1","Rev.Fr.Dias Regin OCD","School Correspondent","http://localhost:8000/backend/uploads/698cc5ae58de28.15156081.png","Welcome to Little Flower Matriculation School. We are committed to providing quality education and nurturing young minds to become responsible citizens of tomorrow.","2026-02-11 23:37:56","2026-02-11 23:39:56");


DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `event_date` datetime NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `events` VALUES("1","Annual Day","2026-02-14 04:00:00","Carmel Nagar ,K.VIllakku","All are Welcome","http://localhost:8000/backend/uploads/698b9ad49f2155.72937349.webp","2026-02-11 02:23:41");


DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT 'General',
  `image_url` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `gallery` VALUES("1","Silambam","Sports","http://localhost:8000/backend/uploads/698c01f9cef388.15840931.jpg","2026-02-11 09:43:49");
INSERT INTO `gallery` VALUES("2","Annual Day","Events","http://localhost:8000/backend/uploads/698c025cabc724.76537157.webp","2026-02-11 09:45:25");
INSERT INTO `gallery` VALUES("3","Library","Academics","http://localhost:8000/backend/uploads/698cbd33287b16.57327837.png","2026-02-11 23:02:43");
INSERT INTO `gallery` VALUES("4","Lab","Academics","http://localhost:8000/backend/uploads/698cbd6ca73882.56578196.png","2026-02-11 23:03:34");
INSERT INTO `gallery` VALUES("5","Yoga","Events","http://localhost:8000/backend/uploads/698cbd8b9f79f5.71311879.png","2026-02-11 23:04:05");
INSERT INTO `gallery` VALUES("6","Tobacco/Liquor  Awareness","General","http://localhost:8000/backend/uploads/698cc0db808cf4.88892349.png","2026-02-11 23:18:12");


DROP TABLE IF EXISTS `hero_slides`;
CREATE TABLE `hero_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) NOT NULL,
  `cta_text` varchar(50) DEFAULT 'Explore Admissions',
  `cta_link` varchar(255) DEFAULT '/admissions',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `hero_slides` VALUES("1","Welcome to Little Flower Matric School","Nurturing Minds, Shaping Futures","http://localhost:8000/backend/uploads/698b904d56d914.58469479.webp","","","1","2026-02-11 01:08:38");
INSERT INTO `hero_slides` VALUES("2","Excellence in Academics","From Pre-KG to VIII, providing holistic education","http://localhost:8000/backend/uploads/698cc32987c740.17241804.png","","","2","2026-02-11 01:08:38");
INSERT INTO `hero_slides` VALUES("3","Life Arts & Extracurriculars","Karate, Silambam, Bharathanatiyam, and more","http://localhost:8000/backend/uploads/698cc31eea1278.71961390.png","","","3","2026-02-11 01:08:38");


DROP TABLE IF EXISTS `mother_teresa_section`;
CREATE TABLE `mother_teresa_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT 'Mother Teresa',
  `photo_url` varchar(255) DEFAULT NULL,
  `proverb` text DEFAULT NULL,
  `vision_title` varchar(255) DEFAULT 'Our Vision',
  `vision_text` text DEFAULT NULL,
  `mission_title` varchar(255) DEFAULT 'Our Mission',
  `mission_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mother_teresa_section` VALUES("1","Mother Teresa","http://localhost:8000/backend/uploads/698cf047eb2e71.04211552.png","Not all of us can do great things. But we can do small things with great love.","Our Vision","To create a society of progressive, thinking individuals who will contribute to the intellectual development of the global community.","Our Mission","To provide a learning environment that encourages children to bring out the best in themselves and enables their all-round development.","2026-02-12 02:32:58","2026-02-12 02:41:11");


DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `excerpt` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `date` date NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `news` VALUES("1","Admission 2026-27","All are Get Ready for the sports ","Little Flower Matriculation School is pleased to announce that admissions are now open for the Academic Year 2026–2027 for classes from Pre-KG to Middle School. We invite parents to visit the campus, meet our experienced faculty, and explore our modern learning facilities. Limited seats are available, and admissions will be granted on a first-come, first-served basis.\n","2026-02-11","http://localhost:8000/backend/uploads/698c0fc73ed4a3.04578350.jpg","Principal","2026-02-11 10:42:42");
INSERT INTO `news` VALUES("2","School Achievements","Our students have achieved outstanding success with a 100% pass result and multiple distinctions.","Little Flower Matriculation School proudly announces a 100% pass result in the recent public examinations. Several students secured distinction marks across subjects, reflecting their dedication and the consistent academic support provided by our experienced faculty. We congratulate our achievers and thank our teachers and parents for their continuous encouragement.\n","2026-02-10","http://localhost:8000/backend/uploads/698c11f83efa94.03428023.jpeg","Principal","2026-02-11 10:52:01");
INSERT INTO `news` VALUES("3","Tree Planting","Students actively participated in a campus-wide tree plantation initiative promoting environmental awareness.","Students actively participated in a campus-wide tree plantation initiative promoting environmental awareness.","2025-11-12","","Admin","2026-02-11 15:50:01");


DROP TABLE IF EXISTS `section_order`;
CREATE TABLE `section_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(50) NOT NULL,
  `display_order` int(11) NOT NULL,
  `is_visible` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_name` (`section_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `section_order` VALUES("1","Hero","1","1","2026-02-12 00:29:24","2026-02-12 00:29:24");
INSERT INTO `section_order` VALUES("2","About","3","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("3","Correspondent","4","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("4","Transport","9","0","2026-02-12 00:29:24","2026-02-12 03:15:30");
INSERT INTO `section_order` VALUES("5","Academics","5","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("6","Events","6","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("7","Gallery","7","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("8","News","8","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("9","Contact","10","1","2026-02-12 00:29:24","2026-02-12 03:10:57");
INSERT INTO `section_order` VALUES("10","MotherTeresa","2","1","2026-02-12 02:32:58","2026-02-12 02:32:58");
INSERT INTO `section_order` VALUES("11","Testimonials","8","1","2026-02-12 08:43:45","2026-02-12 08:43:45");


DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL DEFAULT 1,
  `address` text DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `map_url` text DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `whatsapp_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` VALUES("1","Carmel Nagar,K.Villakku , Virudhunagar  District,  Tamil Nadu 626118","+91 9159352979","contact@littleflowermatricschool.co.in"," https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9110.20953007261!2d78.22670639924979!3d9.406501685654202!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b013fe27a67084f%3A0x300de34c1ac5ba82!2sLittle%20Flower%20Matriculation%20School!5e0!3m2!1sen!2sin!4v1770828593990!5m2!1sen!2sin ","http://localhost:8000/backend/uploads/698cb0fdaf8670.70527477.webp","https://littleflowermatricschool.co.in","https://littleflowermatricschool.co.in","https://littleflowermatricschool.co.in","https://littleflowermatricschool.co.in","https://www.youtube.com/@littleflowerschool9809","2026-02-11 19:11:19","2026-02-12 03:09:35","");


DROP TABLE IF EXISTS `testimonials`;
CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT 'Parent',
  `review` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `testimonials` VALUES("1","Priya  ","","Parent","Excellent school with great focus on holistic development.","2026-02-12 08:43:45");
INSERT INTO `testimonials` VALUES("2","Dr.A.Micheal Raj","","Parent","The teachers are very caring and supportive, and the school provides an excellent environment for students to grow.","2026-02-12 08:43:45");
INSERT INTO `testimonials` VALUES("3","Kokila","","Alumni","I had the best years of my life here. Highly recommended!","2026-02-12 08:43:45");


DROP TABLE IF EXISTS `transport`;
CREATE TABLE `transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `vehicle_photo_url` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `features` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `transport` VALUES("1","Safe & Reliable School Transport","http://localhost:8000/backend/uploads/698cc63f5b3eb7.72684813.png","Our school provides safe and comfortable transportation services for students across the city.","[\"Trained and verified drivers\",\"First Aid Kit\",\"Fire Extinguisher\",\"Regular vehicle maintenance\",\"Female attendant in every bus\",\"Speed governors installed\"]","2026-02-11 23:37:56","2026-02-11 23:41:37");


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin","$2y$12$SiDH3Y..vtPCf4KnGX86y.1A.eFvkl.7a/e0ov2fmM7IWsbXR9OnO","2026-02-11 01:14:51");


