<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch all testimonials
$result = $conn->query("SELECT * FROM testimonials ORDER BY created_at DESC");
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">Manage Testimonials</h1>
        <button onclick="openModal()"
            class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
            <i data-lucide="plus" class="mr-2 h-4 w-4"></i>
            Add Testimonial
        </button>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">

    <!-- Testimonials Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="bg-white overflow-hidden shadow rounded-lg border border-gray-200">
                    <div class="p-5">
                        <div class="flex items-center">
                            <div class="flex-shrink-0">
                                <?php if (!empty($row['photo_url'])): ?>
                                    <img class="h-12 w-12 rounded-full object-cover"
                                        src="<?php echo htmlspecialchars($row['photo_url']); ?>" alt="">
                                <?php else: ?>
                                    <span class="inline-block h-12 w-12 rounded-full overflow-hidden bg-gray-100">
                                        <svg class="h-full w-full text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                                            <path
                                                d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                                        </svg>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="ml-4">
                                <h3 class="text-lg leading-6 font-medium text-gray-900">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </h3>
                                <p class="text-sm text-gray-500">
                                    <?php echo htmlspecialchars($row['role']); ?>
                                </p>
                            </div>
                        </div>
                        <div class="mt-4">
                            <p class="text-sm text-gray-500 italic">"
                                <?php echo htmlspecialchars($row['review']); ?>"
                            </p>
                        </div>
                    </div>
                    <div class="bg-gray-50 px-5 py-3 border-t border-gray-200 sm:flex sm:flex-row-reverse">
                        <button onclick='editTestimonial(<?php echo json_encode($row); ?>)'
                            class="inline-flex w-full justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm">Edit</button>
                        <button onclick="deleteTestimonial(<?php echo $row['id']; ?>)"
                            class="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:w-auto sm:text-sm">Delete</button>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-span-full text-center py-12 text-gray-500">
                No testimonials found. Click "Add Testimonial" to create one.
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal -->
<div id="testimonialModal" class="relative z-10 hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
    <div class="fixed inset-0 z-10 overflow-y-auto">
        <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <div
                class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                <form id="testimonialForm">
                    <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                        <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4" id="modal-title">Add/Edit
                            Testimonial</h3>
                        <input type="hidden" id="testimonialId" name="id">

                        <!-- Photo Upload -->
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700">Photo</label>
                            <div class="mt-2 flex items-center space-x-4">
                                <img id="previewImage" src="" alt="Preview"
                                    class="h-12 w-12 rounded-full object-cover hidden">
                                <input type="hidden" id="photoUrl" name="photo_url">
                                <button type="button" onclick="document.getElementById('fileInput').click()"
                                    class="bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Change</button>
                                <input type="file" id="fileInput" class="hidden" accept="image/*">
                            </div>
                            <p id="uploadStatus" class="mt-1 text-xs text-gray-500"></p>
                        </div>

                        <div class="mb-4">
                            <label for="name" class="block text-sm font-medium text-gray-700">Name</label>
                            <input type="text" name="name" id="name" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                        </div>

                        <div class="mb-4">
                            <label for="role" class="block text-sm font-medium text-gray-700">Role/Designation</label>
                            <input type="text" name="role" id="role" placeholder="e.g. Parent of Class 5 Student"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                        </div>

                        <div class="mb-4">
                            <label for="review" class="block text-sm font-medium text-gray-700">Review</label>
                            <textarea name="review" id="review" rows="4" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"></textarea>
                        </div>
                    </div>
                    <div class="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                        <button type="submit"
                            class="inline-flex w-full justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm">Save</button>
                        <button type="button" onclick="closeModal()"
                            class="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:w-auto sm:text-sm">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    const modal = document.getElementById('testimonialModal');
    const form = document.getElementById('testimonialForm');
    const fileInput = document.getElementById('fileInput');
    const photoUrlInput = document.getElementById('photoUrl');
    const previewImage = document.getElementById('previewImage');
    const uploadStatus = document.getElementById('uploadStatus');

    function openModal() {
        form.reset();
        document.getElementById('testimonialId').value = '';
        document.getElementById('modal-title').textContent = 'Add Testimonial';
        previewImage.classList.add('hidden');
        photoUrlInput.value = '';
        modal.classList.remove('hidden');
    }

    function closeModal() {
        modal.classList.add('hidden');
    }

    function editTestimonial(data) {
        document.getElementById('testimonialId').value = data.id;
        document.getElementById('name').value = data.name;
        document.getElementById('role').value = data.role;
        document.getElementById('review').value = data.review;
        document.getElementById('photoUrl').value = data.photo_url || '';
        document.getElementById('modal-title').textContent = 'Edit Testimonial';

        if (data.photo_url) {
            previewImage.src = data.photo_url;
            previewImage.classList.remove('hidden');
        } else {
            previewImage.classList.add('hidden');
        }

        modal.classList.remove('hidden');
    }

    async function deleteTestimonial(id) {
        if (!confirm('Are you sure you want to delete this testimonial?')) return;

        try {
            const response = await fetch('/backend/api/testimonials.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'delete', id: id })
            });
            const data = await response.json();
            if (data.success) {
                window.location.reload();
            } else {
                alert('Error deleting: ' + (data.error || 'Unknown error'));
            }
        } catch (e) {
            alert('Network error');
        }
    }

    // Handle File Upload
    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        uploadStatus.textContent = 'Uploading...';
        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await fetch('/backend/api/upload.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                photoUrlInput.value = data.url;
                previewImage.src = data.url;
                previewImage.classList.remove('hidden');
                uploadStatus.textContent = 'Uploaded successfully';
                uploadStatus.className = 'mt-1 text-xs text-green-600';
            } else {
                uploadStatus.textContent = 'Error: ' + data.error;
                uploadStatus.className = 'mt-1 text-xs text-red-600';
            }
        } catch (error) {
            uploadStatus.textContent = 'Upload failed';
            uploadStatus.className = 'mt-1 text-xs text-red-600';
        }
    });

    // Handle Form Submit
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = {
            id: document.getElementById('testimonialId').value || undefined,
            name: document.getElementById('name').value,
            role: document.getElementById('role').value,
            review: document.getElementById('review').value,
            photo_url: document.getElementById('photoUrl').value
        };

        try {
            const response = await fetch('/backend/api/testimonials.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            const data = await response.json();

            if (data.success) {
                window.location.reload();
            } else {
                alert('Error saving: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Network error');
        }
    });

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>

<?php require_once 'includes/footer.php'; ?>