<?php
require_once 'includes/header.php';
require_once '../config.php';

// Handle delete
if (isset($_POST['delete_id'])) {
    $stmt = $conn->prepare("DELETE FROM contact_messages WHERE id = ?");
    $stmt->bind_param("i", $_POST['delete_id']);
    $stmt->execute();
}

// Handle status update
if (isset($_POST['mark_read_id'])) {
    $stmt = $conn->prepare("UPDATE contact_messages SET status = 'read' WHERE id = ?");
    $stmt->bind_param("i", $_POST['mark_read_id']);
    $stmt->execute();
}

// Fetch messages
$filter = $_GET['filter'] ?? 'all';
$sql = "SELECT * FROM contact_messages";
if ($filter === 'new') {
    $sql .= " WHERE status = 'new'";
}
$sql .= " ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">Contact Messages</h1>
        <div class="flex space-x-2">
            <a href="?filter=all"
                class="px-3 py-2 rounded-md text-sm font-medium <?php echo $filter === 'all' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500 hover:text-gray-700'; ?>">All</a>
            <a href="?filter=new"
                class="px-3 py-2 rounded-md text-sm font-medium <?php echo $filter === 'new' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500 hover:text-gray-700'; ?>">New</a>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-md">
        <ul class="divide-y divide-gray-200">
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <li class="<?php echo $row['status'] === 'new' ? 'bg-blue-50' : ''; ?>">
                        <div class="px-4 py-4 sm:px-6">
                            <div class="flex items-center justify-between">
                                <p class="text-sm font-medium text-indigo-600 truncate">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </p>
                                <div class="ml-2 flex-shrink-0 flex">
                                    <p
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        <?php echo ucfirst($row['status']); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="mt-2 sm:flex sm:justify-between">
                                <div class="sm:flex">
                                    <p class="flex items-center text-sm text-gray-500">
                                        <i data-lucide="mail" class="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400"></i>
                                        <?php echo htmlspecialchars($row['email']); ?>
                                    </p>
                                    <p class="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                        <i data-lucide="phone" class="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400"></i>
                                        <?php echo htmlspecialchars($row['phone']); ?>
                                    </p>
                                </div>
                                <div class="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                    <i data-lucide="calendar" class="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400"></i>
                                    <p>
                                        <?php echo date('M d, Y h:i A', strtotime($row['created_at'])); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="mt-2">
                                <p class="text-sm font-medium text-gray-900">Subject:
                                    <?php echo htmlspecialchars($row['subject']); ?>
                                </p>
                                <p class="mt-1 text-sm text-gray-500 whitespace-pre-wrap">
                                    <?php echo htmlspecialchars($row['message']); ?>
                                </p>
                            </div>
                            <div class="mt-4 flex space-x-3">
                                <a href="mailto:<?php echo htmlspecialchars($row['email']); ?>?subject=Re: <?php echo htmlspecialchars($row['subject']); ?>"
                                    target="_blank" onclick="markAsRead(<?php echo $row['id']; ?>)"
                                    class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-indigo-700 bg-indigo-100 hover:bg-indigo-200">
                                    <i data-lucide="reply" class="mr-1.5 h-4 w-4"></i>
                                    Reply
                                </a>
                                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $row['phone']); ?>"
                                    target="_blank"
                                    class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-green-700 bg-green-100 hover:bg-green-200">
                                    <i data-lucide="message-circle" class="mr-1.5 h-4 w-4"></i>
                                    WhatsApp
                                </a>
                                <?php if ($row['status'] === 'new'): ?>
                                    <button onclick="markAsRead(<?php echo $row['id']; ?>)"
                                        class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-gray-700 bg-gray-100 hover:bg-gray-200">
                                        <i data-lucide="check" class="mr-1.5 h-4 w-4"></i>
                                        Mark Read
                                    </button>
                                <?php endif; ?>
                                <button onclick="deleteMessage(<?php echo $row['id']; ?>)"
                                    class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-red-700 bg-red-100 hover:bg-red-200">
                                    <i data-lucide="trash-2" class="mr-1.5 h-4 w-4"></i>
                                    Delete
                                </button>
                            </div>
                        </div>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li class="px-4 py-8 text-center text-gray-500">
                    No messages found.
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<form id="actionForm" method="POST" style="display: none;">
    <input type="hidden" name="mark_read_id" id="mark_read_id">
    <input type="hidden" name="delete_id" id="delete_id">
</form>

<script>
    function markAsRead(id) {
        document.getElementById('mark_read_id').value = id;
        document.getElementById('delete_id').disabled = true;
        document.getElementById('actionForm').submit();
    }

    function deleteMessage(id) {
        if (confirm('Are you sure you want to delete this message?')) {
            document.getElementById('delete_id').value = id;
            document.getElementById('delete_id').disabled = false;
            document.getElementById('mark_read_id').disabled = true;
            document.getElementById('actionForm').submit();
        }
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>

<?php require_once 'includes/footer.php'; ?>