<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch gallery images
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Get total count
$total_result = $conn->query("SELECT COUNT(*) as count FROM gallery");
$total_rows = $total_result->fetch_assoc()['count'];
$total_pages = ceil($total_rows / $limit);

// Get images
$sql = "SELECT * FROM gallery ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
$gallery_items = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $gallery_items[] = $row;
    }
}
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">Gallery Management</h1>
        <button onclick="openModal()"
            class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <i data-lucide="plus" class="mr-2 h-4 w-4"></i>
            Add Image
        </button>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-md p-6">
        <!-- Gallery Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach ($gallery_items as $item): ?>
                <div class="relative group border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                    <img src="<?php echo htmlspecialchars($item['image_url']); ?>"
                        alt="<?php echo htmlspecialchars($item['title']); ?>" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="text-sm font-medium text-gray-900 truncate">
                            <?php echo htmlspecialchars($item['title']); ?></h3>
                        <p class="text-xs text-gray-500"><?php echo htmlspecialchars($item['category']); ?></p>
                    </div>
                    <div class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onclick="deleteImage(<?php echo $item['id']; ?>)"
                            class="bg-red-600 text-white p-2 rounded-full hover:bg-red-700 shadow-lg" title="Delete">
                            <i data-lucide="trash-2" class="h-4 w-4"></i>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="mt-8 flex justify-center">
                <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>"
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                            <span class="sr-only">Previous</span>
                            <i data-lucide="chevron-left" class="h-5 w-5"></i>
                        </a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $i === $page ? 'text-indigo-600 bg-indigo-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>"
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                            <span class="sr-only">Next</span>
                            <i data-lucide="chevron-right" class="h-5 w-5"></i>
                        </a>
                    <?php endif; ?>
                </nav>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal -->
<div id="galleryModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
        <div class="mt-3 text-center">
            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modalTitle">Add Image</h3>
            <form id="galleryForm" class="mt-2 text-left">
                <input type="hidden" id="galleryId" name="id">

                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Title</label>
                    <input type="text" id="title" name="title"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        placeholder="Image Title/Description">
                </div>

                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Category</label>
                    <select id="category" name="category"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="General">General</option>
                        <option value="Campus">Campus</option>
                        <option value="Events">Events</option>
                        <option value="Sports">Sports</option>
                        <option value="Academics">Academics</option>
                        <option value="Cultural">Cultural</option>
                    </select>
                </div>

                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Image</label>
                    <input type="file" id="imageInput" accept="image/*"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <input type="hidden" id="imageUrl" name="image_url">
                    <div id="imagePreview" class="mt-2 hidden">
                        <img src="" alt="Preview" class="h-40 w-full object-cover rounded">
                    </div>
                </div>

                <div class="mt-4 flex justify-end space-x-2">
                    <button type="button" onclick="closeModal()"
                        class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                    <button type="submit"
                        class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modal = document.getElementById('galleryModal');
    const form = document.getElementById('galleryForm');
    const imageInput = document.getElementById('imageInput');
    const imageUrl = document.getElementById('imageUrl');
    const imagePreview = document.getElementById('imagePreview');

    // Handle Image Upload to Server first
    imageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('image', file);

        try {
            // Show loading state if desired
            const response = await fetch('/backend/api/upload.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                imageUrl.value = data.url;
                imagePreview.querySelector('img').src = data.url;
                imagePreview.classList.remove('hidden');
            } else {
                alert('Upload failed: ' + data.error);
                imageInput.value = ''; // Reset input
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Upload error');
        }
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const urlToSubmit = document.getElementById('imageUrl').value;
        if (!urlToSubmit) {
            alert('Please select an image first');
            return;
        }

        const formData = {
            title: document.getElementById('title').value,
            category: document.getElementById('category').value,
            image_url: urlToSubmit
        };

        try {
            const response = await fetch('/backend/api/gallery.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                location.reload();
            } else {
                const res = await response.json();
                alert('Error saving image: ' + (res.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error');
        }
    });

    function openModal() {
        form.reset();
        document.getElementById('modalTitle').textContent = 'Add New Image';
        imagePreview.classList.add('hidden');
        modal.classList.remove('hidden');
    }

    function closeModal() {
        modal.classList.add('hidden');
    }

    async function deleteImage(id) {
        if (!confirm('Are you sure you want to delete this image?')) return;

        try {
            const response = await fetch(`/backend/api/gallery.php?id=${id}`, { method: 'DELETE' });
            if (response.ok) {
                location.reload();
            } else {
                alert('Error deleting image');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error');
        }
    }

    // Close modal on click outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });
</script>

<?php require_once 'includes/footer.php'; ?>