<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch current correspondent data
$result = $conn->query("SELECT * FROM correspondent WHERE id = 1");
$data = $result->fetch_assoc();
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <h1 class="text-2xl font-semibold text-gray-900">Correspondent Section</h1>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <form id="correspondentForm" class="space-y-6">

            <!-- Photo Upload -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Correspondent Photo</label>
                <div class="flex items-center space-x-6">
                    <div class="flex-shrink-0">
                        <div id="photoPreview"
                            class="h-32 w-32 rounded-lg border-2 border-gray-300 flex items-center justify-center bg-gray-50 overflow-hidden">
                            <?php if (!empty($data['photo_url'])): ?>
                                <img src="<?php echo htmlspecialchars($data['photo_url']); ?>" alt="Photo"
                                    class="h-full w-full object-cover">
                            <?php else: ?>
                                <i data-lucide="user" class="h-16 w-16 text-gray-400"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="flex-1">
                        <input type="file" id="photoInput" accept=".jpg,.jpeg,.png,.webp" class="hidden">
                        <input type="hidden" id="photo_url" name="photo_url"
                            value="<?php echo htmlspecialchars($data['photo_url'] ?? ''); ?>">
                        <button type="button" onclick="document.getElementById('photoInput').click()"
                            class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            <i data-lucide="upload" class="mr-2 h-4 w-4"></i>
                            Upload Photo
                        </button>
                        <p class="mt-2 text-xs text-gray-500">Max 1MB • JPG, PNG, or WebP</p>
                        <p id="photoStatus" class="mt-1 text-sm"></p>
                    </div>
                </div>
            </div>

            <!-- Name -->
            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($data['name'] ?? ''); ?>"
                    class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
            </div>

            <!-- Designation -->
            <div>
                <label for="designation" class="block text-sm font-medium text-gray-700">Designation</label>
                <input type="text" name="designation" id="designation"
                    value="<?php echo htmlspecialchars($data['designation'] ?? ''); ?>"
                    class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
            </div>

            <!-- Message -->
            <div>
                <label for="message" class="block text-sm font-medium text-gray-700">Message</label>
                <textarea id="message" name="message" rows="6"
                    class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($data['message'] ?? ''); ?></textarea>
            </div>

            <div class="flex justify-end">
                <button type="submit"
                    class="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                    <i data-lucide="save" class="mr-2 h-4 w-4"></i>
                    Save Changes
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const form = document.getElementById('correspondentForm');
    const photoInput = document.getElementById('photoInput');
    const photoPreview = document.getElementById('photoPreview');
    const photoUrlInput = document.getElementById('photo_url');
    const photoStatus = document.getElementById('photoStatus');

    // Handle photo upload
    photoInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (file.size > 1048576) {
            photoStatus.textContent = `Error: File too large (${(file.size / 1048576).toFixed(2)}MB). Max 1MB.`;
            photoStatus.className = 'mt-1 text-sm text-red-600';
            return;
        }

        photoStatus.textContent = 'Uploading...';
        photoStatus.className = 'mt-1 text-sm text-blue-600';

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await fetch('/backend/api/upload.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                photoUrlInput.value = data.url;
                photoPreview.innerHTML = `<img src="${data.url}" alt="Photo" class="h-full w-full object-cover">`;
                photoStatus.textContent = `✓ Uploaded (${data.size})`;
                photoStatus.className = 'mt-1 text-sm text-green-600';
            } else {
                photoStatus.textContent = `Error: ${data.error}`;
                photoStatus.className = 'mt-1 text-sm text-red-600';
            }
        } catch (error) {
            photoStatus.textContent = 'Error: Upload failed';
            photoStatus.className = 'mt-1 text-sm text-red-600';
        }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = {
            name: document.getElementById('name').value,
            designation: document.getElementById('designation').value,
            photo_url: document.getElementById('photo_url').value,
            message: document.getElementById('message').value
        };

        try {
            const response = await fetch('/backend/api/correspondent.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                alert('✓ Correspondent section updated successfully!');
                window.location.reload();
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Network error');
        }
    });

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>

<?php require_once 'includes/footer.php'; ?>