<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch events
$result = $conn->query("SELECT * FROM events ORDER BY event_date ASC");
$events = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">Events Management</h1>
        <button onclick="openModal()"
            class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <i data-lucide="plus" class="mr-2 h-4 w-4"></i>
            Add Event
        </button>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-md">
        <ul class="divide-y divide-gray-200">
            <?php foreach ($events as $event): ?>
                <li class="px-4 py-4 sm:px-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-medium leading-6 text-gray-900">
                                <?php echo htmlspecialchars($event['title']); ?>
                            </h3>
                            <p class="text-sm text-gray-500">
                                <?php echo date('M d, Y', strtotime($event['event_date'])); ?> |
                                <?php echo htmlspecialchars($event['location']); ?>
                            </p>
                        </div>
                        <div class="flex space-x-2">
                            <button onclick='editEvent(<?php echo json_encode($event); ?>)'
                                class="bg-blue-100 text-blue-800 p-2 rounded hover:bg-blue-200">
                                <i data-lucide="edit-2" class="h-4 w-4"></i>
                            </button>
                            <button onclick="deleteEvent(<?php echo $event['id']; ?>)"
                                class="bg-red-100 text-red-800 p-2 rounded hover:bg-red-200">
                                <i data-lucide="trash-2" class="h-4 w-4"></i>
                            </button>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<!-- Modal -->
<div id="eventModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3 text-center">
            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modalTitle">Add New Event</h3>
            <form id="eventForm" class="mt-2 text-left">
                <input type="hidden" id="eventId" name="id">
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Title</label>
                    <input type="text" id="title" name="title"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Date</label>
                    <input type="datetime-local" id="eventDate" name="event_date"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Location</label>
                    <input type="text" id="location" name="location"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Description</label>
                    <textarea id="description" name="description"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Image</label>
                    <input type="file" id="imageInput" accept="image/*"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <input type="hidden" id="imageUrl" name="image_url">
                    <div id="imagePreview" class="mt-2 hidden">
                        <img src="" alt="Preview" class="h-20 w-auto rounded">
                    </div>
                </div>

                <div class="mt-4 flex justify-end space-x-2">
                    <button type="button" onclick="closeModal()"
                        class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                    <button type="submit"
                        class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modal = document.getElementById('eventModal');
    const form = document.getElementById('eventForm');
    const imageInput = document.getElementById('imageInput');
    const imageUrl = document.getElementById('imageUrl');
    const imagePreview = document.getElementById('imagePreview');

    imageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const formData = new FormData();
        formData.append('image', file);
        try {
            const response = await fetch('/backend/api/upload.php', { method: 'POST', body: formData });
            const data = await response.json();
            if (data.success) {
                imageUrl.value = data.url;
                imagePreview.querySelector('img').src = data.url;
                imagePreview.classList.remove('hidden');
            } else { alert('Upload failed: ' + data.error); }
        } catch (error) { console.error('Error:', error); alert('Upload error'); }
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('eventId').value;
        const method = id ? 'PUT' : 'POST';

        const formData = {
            id: id,
            title: document.getElementById('title').value,
            event_date: document.getElementById('eventDate').value,
            location: document.getElementById('location').value,
            description: document.getElementById('description').value,
            image_url: document.getElementById('imageUrl').value
        };

        const response = await fetch('/backend/api/events.php', {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        if (response.ok) location.reload();
        else alert('Error saving event');
    });

    function openModal() {
        form.reset();
        document.getElementById('eventId').value = '';
        document.getElementById('modalTitle').textContent = 'Add New Event';
        imagePreview.classList.add('hidden');
        modal.classList.remove('hidden');
    }

    function closeModal() { modal.classList.add('hidden'); }

    function editEvent(event) {
        document.getElementById('eventId').value = event.id;
        document.getElementById('title').value = event.title;
        document.getElementById('eventDate').value = event.event_date.replace(' ', 'T');
        document.getElementById('location').value = event.location;
        document.getElementById('description').value = event.description;
        document.getElementById('imageUrl').value = event.image_url;

        document.getElementById('modalTitle').textContent = 'Edit Event';
        if (event.image_url) {
            imagePreview.querySelector('img').src = event.image_url;
            imagePreview.classList.remove('hidden');
        }
        modal.classList.remove('hidden');
    }

    async function deleteEvent(id) {
        if (!confirm('Are you sure?')) return;
        const response = await fetch(`/backend/api/events.php?id=${id}`, { method: 'DELETE' });
        if (response.ok) location.reload();
        else alert('Error deleting event');
    }
</script>

<?php require_once 'includes/footer.php'; ?>