<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch existing slides
$result = $conn->query("SELECT * FROM hero_slides ORDER BY sort_order ASC");
$slides = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $slides[] = $row;
    }
}
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">Hero Slider Management</h1>
        <button onclick="openModal()"
            class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <i data-lucide="plus" class="mr-2 h-4 w-4"></i>
            Add Slide
        </button>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-md">
        <ul class="divide-y divide-gray-200">
            <?php foreach ($slides as $slide): ?>
                <li class="px-4 py-4 sm:px-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <img class="h-16 w-16 object-cover rounded"
                                src="<?php echo htmlspecialchars($slide['image_url']); ?>" alt="Slide Image">
                            <div class="ml-4">
                                <h3 class="text-lg font-medium leading-6 text-gray-900">
                                    <?php echo htmlspecialchars($slide['title']); ?>
                                </h3>
                                <p class="text-sm text-gray-500">
                                    <?php echo htmlspecialchars($slide['subtitle']); ?>
                                </p>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button onclick='editSlide(<?php echo json_encode($slide); ?>)'
                                class="bg-blue-100 text-blue-800 p-2 rounded hover:bg-blue-200">
                                <i data-lucide="edit-2" class="h-4 w-4"></i>
                            </button>
                            <button onclick="deleteSlide(<?php echo $slide['id']; ?>)"
                                class="bg-red-100 text-red-800 p-2 rounded hover:bg-red-200">
                                <i data-lucide="trash-2" class="h-4 w-4"></i>
                            </button>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<!-- Modal -->
<div id="slideModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3 text-center">
            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modalTitle">Add New Slide</h3>
            <form id="slideForm" class="mt-2 text-left">
                <input type="hidden" id="slideId" name="id">
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Title</label>
                    <input type="text" id="title" name="title"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Subtitle</label>
                    <input type="text" id="subtitle" name="subtitle"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Image</label>
                    <input type="file" id="imageInput" accept="image/*"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <input type="hidden" id="imageUrl" name="image_url">
                    <div id="imagePreview" class="mt-2 hidden">
                        <img src="" alt="Preview" class="h-20 w-auto rounded">
                    </div>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Order</label>
                    <input type="number" id="sortOrder" name="sort_order"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        value="0">
                </div>
                <div class="mt-4 flex justify-end space-x-2">
                    <button type="button" onclick="closeModal()"
                        class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                    <button type="submit"
                        class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modal = document.getElementById('slideModal');
    const form = document.getElementById('slideForm');
    const imageInput = document.getElementById('imageInput');
    const imageUrl = document.getElementById('imageUrl');
    const imagePreview = document.getElementById('imagePreview');

    // Handle Image Upload
    imageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await fetch('/backend/api/upload.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                imageUrl.value = data.url;
                imagePreview.querySelector('img').src = data.url;
                imagePreview.classList.remove('hidden');
            } else {
                alert('Upload failed: ' + data.error);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Upload error');
        }
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('slideId').value;
        const method = id ? 'PUT' : 'POST';

        const formData = {
            id: id,
            title: document.getElementById('title').value,
            subtitle: document.getElementById('subtitle').value,
            image_url: document.getElementById('imageUrl').value,
            sort_order: document.getElementById('sortOrder').value
        };

        try {
            const response = await fetch('/backend/api/hero.php', {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                location.reload();
            } else {
                alert('Error saving slide');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error saving slide');
        }
    });

    function openModal() {
        form.reset();
        document.getElementById('slideId').value = '';
        document.getElementById('modalTitle').textContent = 'Add New Slide';
        imagePreview.classList.add('hidden');
        modal.classList.remove('hidden');
    }

    function closeModal() {
        modal.classList.add('hidden');
    }

    function editSlide(slide) {
        document.getElementById('slideId').value = slide.id;
        document.getElementById('title').value = slide.title;
        document.getElementById('subtitle').value = slide.subtitle;
        document.getElementById('imageUrl').value = slide.image_url;
        document.getElementById('sortOrder').value = slide.sort_order;

        document.getElementById('modalTitle').textContent = 'Edit Slide';
        imagePreview.querySelector('img').src = slide.image_url;
        imagePreview.classList.remove('hidden');

        modal.classList.remove('hidden');
    }

    async function deleteSlide(id) {
        if (!confirm('Are you sure?')) return;

        try {
            const response = await fetch(`/backend/api/hero.php?id=${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                location.reload();
            } else {
                alert('Error deleting slide');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error deleting slide');
        }
    }
</script>

<?php require_once 'includes/footer.php'; ?>