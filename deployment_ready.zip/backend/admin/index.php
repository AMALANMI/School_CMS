<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch verification counts
$news_count = $conn->query("SELECT COUNT(*) as count FROM news")->fetch_assoc()['count'];
$events_count = $conn->query("SELECT COUNT(*) as count FROM events")->fetch_assoc()['count'];
$gallery_count = $conn->query("SELECT COUNT(*) as count FROM gallery")->fetch_assoc()['count'];
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <h1 class="text-2xl font-semibold text-gray-900">Dashboard</h1>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <!-- News Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-indigo-500 rounded-md p-3">
                        <i data-lucide="newspaper" class="h-6 w-6 text-white"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Total News Items</dt>
                            <dd class="text-lg font-medium text-gray-900">
                                <?php echo $news_count; ?>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-5 py-3">
                <div class="text-sm">
                    <a href="news.php" class="font-medium text-indigo-600 hover:text-indigo-500">View all</a>
                </div>
            </div>
        </div>

        <!-- Events Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-green-500 rounded-md p-3">
                        <i data-lucide="calendar" class="h-6 w-6 text-white"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Upcoming Events</dt>
                            <dd class="text-lg font-medium text-gray-900">
                                <?php echo $events_count; ?>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-5 py-3">
                <div class="text-sm">
                    <a href="events.php" class="font-medium text-indigo-600 hover:text-indigo-500">View all</a>
                </div>
            </div>
        </div>

        <!-- Gallery Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                        <i data-lucide="image" class="h-6 w-6 text-white"></i>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Gallery Images</dt>
                            <dd class="text-lg font-medium text-gray-900">
                                <?php echo $gallery_count; ?>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-5 py-3">
                <div class="text-sm">
                    <a href="gallery.php" class="font-medium text-indigo-600 hover:text-indigo-500">View all</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>