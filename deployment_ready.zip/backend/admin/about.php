<?php
require_once 'includes/header.php';
require_once '../config.php';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <h1 class="text-2xl font-semibold text-gray-900">About Section Management</h1>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <form id="aboutForm">
            <div class="grid grid-cols-1 gap-6">
                <!-- Main Content -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">Subtitle</label>
                    <input type="text" id="subtitle" name="subtitle"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Title</label>
                    <input type="text" id="title" name="title"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Content</label>
                    <textarea id="content" name="content" rows="5"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"></textarea>
                </div>

                <!-- Image -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">Featured Image</label>
                    <div class="mt-1 flex items-center space-x-4">
                        <input type="file" id="imageInput" accept="image/*"
                            class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                        <input type="hidden" id="imageUrl" name="image_url">
                        <div id="imagePreview" class="hidden">
                            <img src="" alt="Preview" class="h-20 w-auto rounded">
                        </div>
                    </div>
                </div>

                <!-- Stats -->
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Students Count</label>
                        <input type="text" id="statsStudents" name="stats_students"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Teachers Count</label>
                        <input type="text" id="statsTeachers" name="stats_teachers"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Classrooms Count</label>
                        <input type="text" id="statsClassrooms" name="stats_classrooms"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Years of Excellence</label>
                        <input type="text" id="statsYears" name="stats_years"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Save
                        Changes</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    // Load existing data
    fetch('/backend/api/about.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('title').value = data.title;
            document.getElementById('subtitle').value = data.subtitle;
            document.getElementById('content').value = data.content;
            document.getElementById('imageUrl').value = data.image_url;
            document.getElementById('statsStudents').value = data.stats_students;
            document.getElementById('statsTeachers').value = data.stats_teachers;
            document.getElementById('statsClassrooms').value = data.stats_classrooms;
            document.getElementById('statsYears').value = data.stats_years;

            if (data.image_url) {
                const preview = document.getElementById('imagePreview');
                preview.querySelector('img').src = data.image_url;
                preview.classList.remove('hidden');
            }
        });

    // Handle Image Upload
    document.getElementById('imageInput').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await fetch('/backend/api/upload.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                document.getElementById('imageUrl').value = data.url;
                const preview = document.getElementById('imagePreview');
                preview.querySelector('img').src = data.url;
                preview.classList.remove('hidden');
            } else {
                alert('Upload failed: ' + data.error);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Upload error');
        }
    });

    document.getElementById('aboutForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = {
            title: document.getElementById('title').value,
            subtitle: document.getElementById('subtitle').value,
            content: document.getElementById('content').value,
            image_url: document.getElementById('imageUrl').value,
            stats_students: document.getElementById('statsStudents').value,
            stats_teachers: document.getElementById('statsTeachers').value,
            stats_classrooms: document.getElementById('statsClassrooms').value,
            stats_years: document.getElementById('statsYears').value,
        };

        try {
            const response = await fetch('/backend/api/about.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                alert('Changes saved successfully');
            } else {
                alert('Error saving changes');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error saving changes');
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>