<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch current settings
$result = $conn->query("SELECT * FROM settings WHERE id = 1");
$settings = $result->fetch_assoc();
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">Site Settings</h1>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <!-- Upload Restrictions Notice -->
    <div class="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6">
        <div class="flex">
            <div class="flex-shrink-0">
                <i data-lucide="info" class="h-5 w-5 text-blue-400"></i>
            </div>
            <div class="ml-3">
                <p class="text-sm text-blue-700">
                    <strong>Image Upload Restrictions:</strong> Maximum file size is <strong>1MB</strong>.
                    Allowed formats: <strong>.jpg, .jpeg, .png, .webp</strong> only.
                </p>
            </div>
        </div>
    </div>

    <div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <form id="settingsForm" class="space-y-8">

            <!-- Logo Section -->
            <div class="border-b border-gray-200 pb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">School Logo</h3>

                <div class="flex items-center space-x-6">
                    <!-- Logo Preview -->
                    <div class="flex-shrink-0">
                        <div id="logoPreview"
                            class="h-24 w-24 rounded-lg border-2 border-gray-300 flex items-center justify-center bg-gray-50 overflow-hidden">
                            <?php if (!empty($settings['logo_url'])): ?>
                                <img src="<?php echo htmlspecialchars($settings['logo_url']); ?>" alt="Logo"
                                    class="h-full w-full object-contain">
                            <?php else: ?>
                                <i data-lucide="image" class="h-12 w-12 text-gray-400"></i>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Upload Button -->
                    <div class="flex-1">
                        <input type="file" id="logoInput" accept=".jpg,.jpeg,.png,.webp" class="hidden">
                        <input type="hidden" id="logo_url" name="logo_url"
                            value="<?php echo htmlspecialchars($settings['logo_url'] ?? ''); ?>">

                        <button type="button" onclick="document.getElementById('logoInput').click()"
                            class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            <i data-lucide="upload" class="mr-2 h-4 w-4"></i>
                            Upload Logo
                        </button>
                        <p class="mt-2 text-xs text-gray-500">Max 1MB • JPG, PNG, or WebP</p>
                        <p id="logoStatus" class="mt-1 text-sm"></p>
                    </div>
                </div>
            </div>

            <!-- Contact Information -->
            <div class="border-b border-gray-200 pb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Contact Information</h3>

                <!-- Address -->
                <div class="mb-4">
                    <label for="address" class="block text-sm font-medium text-gray-700">School Address</label>
                    <div class="mt-1">
                        <textarea id="address" name="address" rows="3"
                            class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                            placeholder="123 Education Avenue..."><?php echo htmlspecialchars($settings['address'] ?? ''); ?></textarea>
                    </div>
                </div>

                <div class="grid grid-cols-1 gap-y-4 gap-x-4 sm:grid-cols-2">
                    <!-- Phone -->
                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700">Phone Number</label>
                        <div class="mt-1">
                            <input type="text" name="phone" id="phone"
                                value="<?php echo htmlspecialchars($settings['phone'] ?? ''); ?>"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                        </div>
                    </div>

                    <!-- Email -->
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                        <div class="mt-1">
                            <input type="email" name="email" id="email"
                                value="<?php echo htmlspecialchars($settings['email'] ?? ''); ?>"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="info@school.edu.in">
                        </div>
                    </div>

                    <!-- WhatsApp Number -->
                    <div class="col-span-1 sm:col-span-2 md:col-span-1">
                        <label for="whatsapp_number" class="block text-sm font-medium text-gray-700">WhatsApp
                            Number</label>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i data-lucide="message-circle" class="h-4 w-4 text-green-500"></i>
                            </div>
                            <input type="text" name="whatsapp_number" id="whatsapp_number"
                                value="<?php echo htmlspecialchars($settings['whatsapp_number'] ?? ''); ?>"
                                class="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                                placeholder="+91 98765 43210">
                        </div>
                        <p class="mt-1 text-xs text-gray-500">Used for WhatsApp links.</p>
                    </div>
                </div>
            </div>

            <!-- Social Media Links -->
            <div class="border-b border-gray-200 pb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Social Media Links</h3>
                <p class="text-sm text-gray-500 mb-4">Enter full URLs for your social media profiles. Use '#' to hide
                    the icon.</p>

                <div class="grid grid-cols-1 gap-y-4 gap-x-4 sm:grid-cols-2">
                    <!-- Facebook -->
                    <div>
                        <label for="facebook_url" class="block text-sm font-medium text-gray-700">
                            <i data-lucide="facebook" class="inline h-4 w-4 mr-1"></i> Facebook
                        </label>
                        <input type="url" name="facebook_url" id="facebook_url"
                            value="<?php echo htmlspecialchars($settings['facebook_url'] ?? '#'); ?>"
                            placeholder="https://facebook.com/yourpage"
                            class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                    </div>

                    <!-- Twitter -->
                    <div>
                        <label for="twitter_url" class="block text-sm font-medium text-gray-700">
                            <i data-lucide="twitter" class="inline h-4 w-4 mr-1"></i> Twitter
                        </label>
                        <input type="url" name="twitter_url" id="twitter_url"
                            value="<?php echo htmlspecialchars($settings['twitter_url'] ?? '#'); ?>"
                            placeholder="https://twitter.com/yourhandle"
                            class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                    </div>

                    <!-- Instagram -->
                    <div>
                        <label for="instagram_url" class="block text-sm font-medium text-gray-700">
                            <i data-lucide="instagram" class="inline h-4 w-4 mr-1"></i> Instagram
                        </label>
                        <input type="url" name="instagram_url" id="instagram_url"
                            value="<?php echo htmlspecialchars($settings['instagram_url'] ?? '#'); ?>"
                            placeholder="https://instagram.com/yourprofile"
                            class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                    </div>

                    <!-- LinkedIn -->
                    <div>
                        <label for="linkedin_url" class="block text-sm font-medium text-gray-700">
                            <i data-lucide="linkedin" class="inline h-4 w-4 mr-1"></i> LinkedIn
                        </label>
                        <input type="url" name="linkedin_url" id="linkedin_url"
                            value="<?php echo htmlspecialchars($settings['linkedin_url'] ?? '#'); ?>"
                            placeholder="https://linkedin.com/company/yourcompany"
                            class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                    </div>

                    <!-- YouTube -->
                    <div>
                        <label for="youtube_url" class="block text-sm font-medium text-gray-700">
                            <i data-lucide="youtube" class="inline h-4 w-4 mr-1"></i> YouTube
                        </label>
                        <input type="url" name="youtube_url" id="youtube_url"
                            value="<?php echo htmlspecialchars($settings['youtube_url'] ?? '#'); ?>"
                            placeholder="https://youtube.com/@yourchannel"
                            class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                    </div>
                </div>
            </div>

            <!-- Map URL -->
            <div class="border-b border-gray-200 pb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Google Maps</h3>

                <div>
                    <label for="map_url" class="block text-sm font-medium text-gray-700">Google Maps Embed URL</label>
                    <div class="mt-1">
                        <textarea id="map_url" name="map_url" rows="3"
                            class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                            placeholder="https://www.google.com/maps/embed..."><?php echo htmlspecialchars($settings['map_url'] ?? ''); ?></textarea>
                    </div>
                    <p class="mt-2 text-sm text-gray-500">Copy the 'src' attribute from Google Maps Embed code.</p>
                </div>

                <!-- Preview Map -->
                <div id="mapPreview"
                    class="mt-4 aspect-video w-full rounded-lg overflow-hidden border bg-gray-100 relative">
                    <p class="absolute inset-0 flex items-center justify-center text-gray-400 z-10">Map Preview</p>
                    <iframe src="<?php echo htmlspecialchars($settings['map_url'] ?? ''); ?>" width="100%" height="100%"
                        style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>

            <!-- Section Order Management -->
            <div class="border-b border-gray-200 pb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Homepage Section Order</h3>
                <p class="text-sm text-gray-600 mb-4">Drag sections or use arrows to reorder homepage sections. Changes
                    are saved separately.</p>

                <div id="sectionOrderList" class="space-y-2">
                    <!-- Sections will be loaded here dynamically -->
                </div>

                <button type="button" id="saveSectionOrder"
                    class="mt-4 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700">
                    <i data-lucide="save" class="mr-2 h-4 w-4"></i>
                    Save Section Order
                </button>
                <p id="sectionOrderStatus" class="mt-2 text-sm"></p>
            </div>

            <div class="flex justify-end">
                <button type="submit"
                    class="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    <i data-lucide="save" class="mr-2 h-4 w-4"></i>
                    Save All Settings
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const form = document.getElementById('settingsForm');
    const mapInput = document.getElementById('map_url');
    const mapPreview = document.querySelector('#mapPreview iframe');
    const logoInput = document.getElementById('logoInput');
    const logoPreview = document.getElementById('logoPreview');
    const logoUrlInput = document.getElementById('logo_url');
    const logoStatus = document.getElementById('logoStatus');

    // Live preview of map - only update if it's a valid Google Maps embed URL
    mapInput.addEventListener('input', (e) => {
        const url = e.target.value.trim();
        // Check if it's a Google Maps embed URL
        if (url && (url.includes('google.com/maps/embed') || url.includes('maps.google.com'))) {
            mapPreview.src = url;
        } else if (!url) {
            // Clear the iframe if input is empty
            mapPreview.src = '';
        }
        // Don't update iframe for invalid URLs to prevent loading the current page
    });

    // Handle logo upload
    logoInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // Validate file size (1MB = 1048576 bytes)
        if (file.size > 1048576) {
            const sizeMB = (file.size / 1048576).toFixed(2);
            logoStatus.textContent = `Error: File too large (${sizeMB}MB). Max 1MB allowed.`;
            logoStatus.className = 'mt-1 text-sm text-red-600';
            return;
        }

        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            logoStatus.textContent = 'Error: Invalid file type. Use JPG, PNG, or WebP.';
            logoStatus.className = 'mt-1 text-sm text-red-600';
            return;
        }

        logoStatus.textContent = 'Uploading...';
        logoStatus.className = 'mt-1 text-sm text-blue-600';

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await fetch('/backend/api/upload.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                logoUrlInput.value = data.url;
                logoPreview.innerHTML = `<img src="${data.url}" alt="Logo" class="h-full w-full object-contain">`;
                logoStatus.textContent = `✓ Uploaded successfully (${data.size})`;
                logoStatus.className = 'mt-1 text-sm text-green-600';
            } else {
                logoStatus.textContent = `Error: ${data.error}`;
                logoStatus.className = 'mt-1 text-sm text-red-600';
            }
        } catch (error) {
            logoStatus.textContent = 'Error: Upload failed';
            logoStatus.className = 'mt-1 text-sm text-red-600';
        }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = {
            address: document.getElementById('address').value,
            phone: document.getElementById('phone').value,
            email: document.getElementById('email').value,
            map_url: document.getElementById('map_url').value,
            logo_url: document.getElementById('logo_url').value,
            facebook_url: document.getElementById('facebook_url').value,
            twitter_url: document.getElementById('twitter_url').value,
            instagram_url: document.getElementById('instagram_url').value,
            linkedin_url: document.getElementById('linkedin_url').value,
            youtube_url: document.getElementById('youtube_url').value
        };

        try {
            const response = await fetch('/backend/api/settings.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                alert('✓ Settings saved successfully!');
                window.location.reload();
            } else {
                alert('Error saving settings: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error');
        }
    });

    // Section Order Logic
    const sectionOrderList = document.getElementById('sectionOrderList');
    const saveSectionOrderBtn = document.getElementById('saveSectionOrder');
    const sectionOrderStatus = document.getElementById('sectionOrderStatus');
    let sections = [];

    // Fetch current section order
    async function fetchSectionOrder() {
        try {
            const response = await fetch('/backend/api/section_order.php');
            const data = await response.json();
            if (Array.isArray(data)) {
                sections = data;
                renderSections();
            }
        } catch (error) {
            console.error('Error fetching section order:', error);
        }
    }

    // Render section list
    function renderSections() {
        sectionOrderList.innerHTML = '';
        sections.forEach((section, index) => {
            const div = document.createElement('div');
            div.className = 'flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-md';
            div.innerHTML = `
                <div class="flex items-center space-x-3">
                    <span class="font-medium text-gray-700">${section.section_name}</span>
                    <label class="inline-flex items-center cursor-pointer">
                        <input type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 rounded" 
                            ${section.is_visible == 1 ? 'checked' : ''} 
                            onchange="toggleVisibility(${index})">
                        <span class="ml-2 text-xs text-gray-500">Visible</span>
                    </label>
                </div>
                <div class="flex items-center space-x-2">
                    <button type="button" onclick="moveSection(${index}, -1)" 
                        class="p-1 rounded-md hover:bg-gray-200 ${index === 0 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600'}"
                        ${index === 0 ? 'disabled' : ''}>
                        <i data-lucide="arrow-up" class="h-4 w-4"></i>
                    </button>
                    <button type="button" onclick="moveSection(${index}, 1)" 
                        class="p-1 rounded-md hover:bg-gray-200 ${index === sections.length - 1 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600'}"
                        ${index === sections.length - 1 ? 'disabled' : ''}>
                        <i data-lucide="arrow-down" class="h-4 w-4"></i>
                    </button>
                </div>
            `;
            sectionOrderList.appendChild(div);
        });

        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    // Move section
    window.moveSection = (index, direction) => {
        const newIndex = index + direction;
        if (newIndex >= 0 && newIndex < sections.length) {
            // Swap display_order values to keep them consistent
            // Actually, we just swap positions in the array and re-assign display_order before saving
            const temp = sections[index];
            sections[index] = sections[newIndex];
            sections[newIndex] = temp;

            renderSections();
        }
    };

    // Toggle visibility
    window.toggleVisibility = (index) => {
        sections[index].is_visible = sections[index].is_visible == 1 ? 0 : 1;
    };

    // Save section order
    saveSectionOrderBtn.addEventListener('click', async () => {
        sectionOrderStatus.textContent = 'Saving...';
        sectionOrderStatus.className = 'mt-2 text-sm text-blue-600';

        // Update display_order based on array index
        const updatedSections = sections.map((section, index) => ({
            ...section,
            display_order: index + 1
        }));

        try {
            const response = await fetch('/backend/api/section_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ sections: updatedSections })
            });
            const data = await response.json();

            if (data.success) {
                sectionOrderStatus.textContent = '✓ Order saved successfully!';
                sectionOrderStatus.className = 'mt-2 text-sm text-green-600';
                sections = updatedSections;
                // Optional: reload page to see changes if needed, but not strictly necessary here
            } else {
                sectionOrderStatus.textContent = 'Error: ' + (data.error || 'Unknown error');
                sectionOrderStatus.className = 'mt-2 text-sm text-red-600';
            }
        } catch (error) {
            sectionOrderStatus.textContent = 'Network error';
            sectionOrderStatus.className = 'mt-2 text-sm text-red-600';
        }
    });

    // Initial fetch
    fetchSectionOrder();

    // Initialize Lucide icons for existing content
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>

<?php require_once 'includes/footer.php'; ?>