<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch news
$result = $conn->query("SELECT * FROM news ORDER BY date DESC");
$news_items = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $news_items[] = $row;
    }
}
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-900">News Management</h1>
        <button onclick="openModal()"
            class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <i data-lucide="plus" class="mr-2 h-4 w-4"></i>
            Add News
        </button>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-md">
        <ul class="divide-y divide-gray-200">
            <?php foreach ($news_items as $item): ?>
                <li class="px-4 py-4 sm:px-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-medium leading-6 text-gray-900">
                                <?php echo htmlspecialchars($item['title']); ?>
                            </h3>
                            <p class="text-sm text-gray-500">
                                <?php echo date('M d, Y', strtotime($item['date'])); ?> |
                                <?php echo htmlspecialchars($item['author']); ?>
                            </p>
                        </div>
                        <div class="flex space-x-2">
                            <button onclick='editNews(<?php echo json_encode($item); ?>)'
                                class="bg-blue-100 text-blue-800 p-2 rounded hover:bg-blue-200">
                                <i data-lucide="edit-2" class="h-4 w-4"></i>
                            </button>
                            <button onclick="deleteNews(<?php echo $item['id']; ?>)"
                                class="bg-red-100 text-red-800 p-2 rounded hover:bg-red-200">
                                <i data-lucide="trash-2" class="h-4 w-4"></i>
                            </button>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<!-- Modal -->
<div id="newsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-3/4 shadow-lg rounded-md bg-white">
        <div class="mt-3 text-center">
            <h3 class="text-lg leading-6 font-medium text-gray-900" id="modalTitle">Add News</h3>
            <form id="newsForm" class="mt-2 text-left">
                <input type="hidden" id="newsId" name="id">
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Title</label>
                    <input type="text" id="title" name="title"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Date</label>
                    <input type="date" id="newsDate" name="date"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Author</label>
                    <input type="text" id="author" name="author"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        value="Admin">
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Excerpt</label>
                    <textarea id="excerpt" name="excerpt" rows="2"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Content</label>
                    <textarea id="content" name="content" rows="6"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                </div>
                <div class="mt-2">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Image</label>
                    <input type="file" id="imageInput" accept="image/*"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <input type="hidden" id="imageUrl" name="image_url">
                    <div id="imagePreview" class="mt-2 hidden">
                        <img src="" alt="Preview" class="h-20 w-auto rounded">
                    </div>
                </div>

                <div class="mt-4 flex justify-end space-x-2">
                    <button type="button" onclick="closeModal()"
                        class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Cancel</button>
                    <button type="submit"
                        class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modal = document.getElementById('newsModal');
    const form = document.getElementById('newsForm');
    const imageInput = document.getElementById('imageInput');
    const imageUrl = document.getElementById('imageUrl');
    const imagePreview = document.getElementById('imagePreview');

    imageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const formData = new FormData();
        formData.append('image', file);
        try {
            const response = await fetch('/backend/api/upload.php', { method: 'POST', body: formData });
            const data = await response.json();
            if (data.success) {
                imageUrl.value = data.url;
                imagePreview.querySelector('img').src = data.url;
                imagePreview.classList.remove('hidden');
            } else { alert('Upload failed: ' + data.error); }
        } catch (error) { console.error('Error:', error); alert('Upload error'); }
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('newsId').value;
        const method = id ? 'PUT' : 'POST';

        const formData = {
            id: id,
            title: document.getElementById('title').value,
            date: document.getElementById('newsDate').value,
            author: document.getElementById('author').value,
            excerpt: document.getElementById('excerpt').value,
            content: document.getElementById('content').value,
            image_url: document.getElementById('imageUrl').value
        };

        const response = await fetch('/backend/api/news.php', {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        if (response.ok) location.reload();
        else alert('Error saving news');
    });

    function openModal() {
        form.reset();
        document.getElementById('newsId').value = '';
        document.getElementById('modalTitle').textContent = 'Add News';
        imagePreview.classList.add('hidden');
        modal.classList.remove('hidden');
    }

    function closeModal() { modal.classList.add('hidden'); }

    function editNews(item) {
        document.getElementById('newsId').value = item.id;
        document.getElementById('title').value = item.title;
        document.getElementById('newsDate').value = item.date;
        document.getElementById('author').value = item.author;
        document.getElementById('excerpt').value = item.excerpt;
        document.getElementById('content').value = item.content;
        document.getElementById('imageUrl').value = item.image_url;

        document.getElementById('modalTitle').textContent = 'Edit News';
        if (item.image_url) {
            imagePreview.querySelector('img').src = item.image_url;
            imagePreview.classList.remove('hidden');
        }
        modal.classList.remove('hidden');
    }

    async function deleteNews(id) {
        if (!confirm('Are you sure?')) return;
        const response = await fetch(`/backend/api/news.php?id=${id}`, { method: 'DELETE' });
        if (response.ok) location.reload();
        else alert('Error deleting news');
    }
</script>

<?php require_once 'includes/footer.php'; ?>