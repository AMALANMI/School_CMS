<?php
require_once 'includes/header.php';
require_once '../config.php';

// Fetch current transport data
$result = $conn->query("SELECT * FROM transport WHERE id = 1");
$data = $result->fetch_assoc();
$features = json_decode($data['features'] ?? '[]', true);
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <h1 class="text-2xl font-semibold text-gray-900">Transport / Vehicle Services</h1>
</div>

<div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
    <div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <form id="transportForm" class="space-y-6">

            <!-- Vehicle Photo Upload -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Vehicle Photo</label>
                <div class="flex items-center space-x-6">
                    <div class="flex-shrink-0">
                        <div id="vehiclePreview"
                            class="h-48 w-64 rounded-lg border-2 border-gray-300 flex items-center justify-center bg-gray-50 overflow-hidden">
                            <?php if (!empty($data['vehicle_photo_url'])): ?>
                                <img src="<?php echo htmlspecialchars($data['vehicle_photo_url']); ?>" alt="Vehicle"
                                    class="h-full w-full object-cover">
                            <?php else: ?>
                                <i data-lucide="bus" class="h-24 w-24 text-gray-400"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="flex-1">
                        <input type="file" id="vehicleInput" accept=".jpg,.jpeg,.png,.webp" class="hidden">
                        <input type="hidden" id="vehicle_photo_url" name="vehicle_photo_url"
                            value="<?php echo htmlspecialchars($data['vehicle_photo_url'] ?? ''); ?>">
                        <button type="button" onclick="document.getElementById('vehicleInput').click()"
                            class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                            <i data-lucide="upload" class="mr-2 h-4 w-4"></i>
                            Upload Vehicle Photo
                        </button>
                        <p class="mt-2 text-xs text-gray-500">Max 1MB • JPG, PNG, or WebP</p>
                        <p id="vehicleStatus" class="mt-1 text-sm"></p>
                    </div>
                </div>
            </div>

            <!-- Title -->
            <div>
                <label for="title" class="block text-sm font-medium text-gray-700">Title</label>
                <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($data['title'] ?? ''); ?>"
                    class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
            </div>

            <!-- Description -->
            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea id="description" name="description" rows="4"
                    class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"><?php echo htmlspecialchars($data['description'] ?? ''); ?></textarea>
            </div>

            <!-- Features -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Safety Features</label>
                <div id="featuresList" class="space-y-2">
                    <?php foreach ($features as $index => $feature): ?>
                        <div class="flex items-center space-x-2 feature-item">
                            <input type="text" value="<?php echo htmlspecialchars($feature); ?>"
                                class="feature-input flex-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                            <button type="button" onclick="this.parentElement.remove()"
                                class="inline-flex items-center p-2 border border-red-300 text-red-700 rounded-md hover:bg-red-50">
                                <i data-lucide="x" class="h-4 w-4"></i>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" id="addFeatureBtn"
                    class="mt-3 inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    <i data-lucide="plus" class="mr-2 h-4 w-4"></i>
                    Add Feature
                </button>
            </div>

            <div class="flex justify-end">
                <button type="submit"
                    class="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                    <i data-lucide="save" class="mr-2 h-4 w-4"></i>
                    Save Changes
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const form = document.getElementById('transportForm');
    const vehicleInput = document.getElementById('vehicleInput');
    const vehiclePreview = document.getElementById('vehiclePreview');
    const vehicleUrlInput = document.getElementById('vehicle_photo_url');
    const vehicleStatus = document.getElementById('vehicleStatus');
    const featuresList = document.getElementById('featuresList');
    const addFeatureBtn = document.getElementById('addFeatureBtn');

    // Handle vehicle photo upload
    vehicleInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (file.size > 1048576) {
            vehicleStatus.textContent = `Error: File too large (${(file.size / 1048576).toFixed(2)}MB). Max 1MB.`;
            vehicleStatus.className = 'mt-1 text-sm text-red-600';
            return;
        }

        vehicleStatus.textContent = 'Uploading...';
        vehicleStatus.className = 'mt-1 text-sm text-blue-600';

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await fetch('/backend/api/upload.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                vehicleUrlInput.value = data.url;
                vehiclePreview.innerHTML = `<img src="${data.url}" alt="Vehicle" class="h-full w-full object-cover">`;
                vehicleStatus.textContent = `✓ Uploaded (${data.size})`;
                vehicleStatus.className = 'mt-1 text-sm text-green-600';
            } else {
                vehicleStatus.textContent = `Error: ${data.error}`;
                vehicleStatus.className = 'mt-1 text-sm text-red-600';
            }
        } catch (error) {
            vehicleStatus.textContent = 'Error: Upload failed';
            vehicleStatus.className = 'mt-1 text-sm text-red-600';
        }
    });

    // Add feature
    addFeatureBtn.addEventListener('click', () => {
        const div = document.createElement('div');
        div.className = 'flex items-center space-x-2 feature-item';
        div.innerHTML = `
            <input type="text" placeholder="Enter feature..." 
                class="feature-input flex-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
            <button type="button" onclick="this.parentElement.remove()" 
                class="inline-flex items-center p-2 border border-red-300 text-red-700 rounded-md hover:bg-red-50">
                <i data-lucide="x" class="h-4 w-4"></i>
            </button>
        `;
        featuresList.appendChild(div);
        lucide.createIcons();
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Collect features
        const featureInputs = document.querySelectorAll('.feature-input');
        const features = Array.from(featureInputs)
            .map(input => input.value.trim())
            .filter(val => val !== '');

        const formData = {
            title: document.getElementById('title').value,
            vehicle_photo_url: document.getElementById('vehicle_photo_url').value,
            description: document.getElementById('description').value,
            features: features
        };

        try {
            const response = await fetch('/backend/api/transport.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                alert('✓ Transport section updated successfully!');
                window.location.reload();
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            alert('Network error');
        }
    });

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>

<?php require_once 'includes/footer.php'; ?>