<?php
// backend/admin/includes/header.php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /backend/admin/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Little Flower School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        /* 3D Text Animation Styles */
        @keyframes float {

            0%,
            100% {
                transform: translateY(0px) rotateX(0deg);
            }

            50% {
                transform: translateY(-10px) rotateX(5deg);
            }
        }

        @keyframes shimmer {
            0% {
                background-position: -200% center;
            }

            100% {
                background-position: 200% center;
            }
        }

        @keyframes glow {

            0%,
            100% {
                text-shadow: 0 0 10px rgba(251, 191, 36, 0.5), 0 0 20px rgba(251, 191, 36, 0.3);
            }

            50% {
                text-shadow: 0 0 20px rgba(251, 191, 36, 0.8), 0 0 30px rgba(251, 191, 36, 0.5), 0 0 40px rgba(251, 191, 36, 0.3);
            }
        }

        .brand-title {
            background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 50%, #fbbf24 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: shimmer 3s linear infinite, float 4s ease-in-out infinite;
            font-weight: 800;
            letter-spacing: -0.02em;
            transform-style: preserve-3d;
            perspective: 1000px;
        }

        .slogan {
            background: linear-gradient(135deg, #94a3b8 0%, #cbd5e1 50%, #94a3b8 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: shimmer 4s linear infinite, glow 2s ease-in-out infinite;
            font-weight: 600;
            letter-spacing: 0.1em;
            text-transform: uppercase;
        }

        .brand-container {
            position: relative;
            overflow: hidden;
        }

        .brand-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(251, 191, 36, 0.1) 0%, transparent 70%);
            animation: rotate 10s linear infinite;
        }

        @keyframes rotate {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        /* Mobile menu transition */
        .mobile-menu {
            transition: transform 0.3s ease-in-out;
        }

        .mobile-menu.hidden {
            transform: translateX(-100%);
        }

        /* Responsive footer */
        @media (max-width: 768px) {
            .admin-footer {
                position: relative !important;
            }
        }
    </style>
    <script>
        // Initialize Lucide icons
        document.addEventListener("DOMContentLoaded", () => {
            lucide.createIcons();
        });

        // Mobile menu toggle
        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            const overlay = document.getElementById('menu-overlay');
            menu.classList.toggle('hidden');
            overlay.classList.toggle('hidden');
        }
    </script>
</head>

<body class="bg-gray-100 min-h-screen font-sans">
    <div class="flex h-screen overflow-hidden">
        <!-- Mobile Menu Overlay -->
        <div id="menu-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 hidden md:hidden"
            onclick="toggleMobileMenu()"></div>

        <!-- Mobile Sidebar -->
        <div id="mobile-menu"
            class="mobile-menu hidden fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 text-white md:hidden">
            <div class="flex flex-col h-full">
                <!-- Mobile Brand Header -->
                <div
                    class="brand-container h-32 border-b border-slate-800 flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
                    <h1 class="brand-title text-base text-center mb-2">
                        Amalan AK International Technologies
                    </h1>
                    <p class="slogan text-xs text-center">
                        Momentum Beyond Measure
                    </p>
                </div>

                <div class="flex-1 flex flex-col overflow-y-auto">
                    <nav class="flex-1 px-2 py-4 space-y-1">
                        <a href="/backend/admin/index.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'index.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="layout-dashboard" class="mr-3 h-6 w-6"></i>
                            Dashboard
                        </a>
                        <a href="/backend/admin/messages.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'messages.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="mail" class="mr-3 h-6 w-6"></i>
                            Messages
                        </a>
                        <a href="/backend/admin/hero.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'hero.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="image" class="mr-3 h-6 w-6"></i>
                            Hero Slider
                        </a>
                        <a href="/backend/admin/about.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'about.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="info" class="mr-3 h-6 w-6"></i>
                            About Section
                        </a>
                        <a href="/backend/admin/events.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'events.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="calendar" class="mr-3 h-6 w-6"></i>
                            Events
                        </a>
                        <a href="/backend/admin/news.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'news.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="newspaper" class="mr-3 h-6 w-6"></i>
                            News
                        </a>
                        <a href="/backend/admin/gallery.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'gallery.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="image-plus" class="mr-3 h-6 w-6"></i>
                            Gallery
                        </a>
                        <a href="/backend/admin/mother_teresa.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'mother_teresa.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="heart" class="mr-3 h-6 w-6"></i>
                            Mother Teresa
                        </a>
                        <a href="/backend/admin/correspondent.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'correspondent.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="user-circle" class="mr-3 h-6 w-6"></i>
                            Correspondent
                        </a>
                        <a href="/backend/admin/transport.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'transport.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="bus" class="mr-3 h-6 w-6"></i>
                            Transport
                        </a>
                        <a href="/backend/admin/testimonials.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'testimonials.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="message-square" class="mr-3 h-6 w-6"></i>
                            Testimonials
                        </a>
                        <a href="/backend/admin/settings.php" onclick="toggleMobileMenu()"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'settings.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="settings" class="mr-3 h-6 w-6"></i>
                            Settings
                        </a>
                    </nav>
                </div>
                <div class="flex-shrink-0 flex border-t border-slate-800 p-4">
                    <a href="/backend/auth/logout.php" class="flex-shrink-0 w-full group block">
                        <div class="flex items-center">
                            <i data-lucide="log-out" class="inline-block h-9 w-9 rounded-full text-slate-400"></i>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-white group-hover:text-slate-200">Logout</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Desktop Sidebar -->
        <div class="hidden md:flex md:flex-shrink-0">
            <div class="flex flex-col w-64 bg-slate-900 text-white">
                <!-- Animated Brand Header -->
                <div
                    class="brand-container h-32 border-b border-slate-800 flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
                    <h1 class="brand-title text-xl text-center mb-2">
                        Amalan AK International Technologies
                    </h1>
                    <p class="slogan text-xs text-center">
                        Momentum Beyond Measure
                    </p>
                </div>

                <div class="flex-1 flex flex-col overflow-y-auto">
                    <nav class="flex-1 px-2 py-4 space-y-1">
                        <a href="/backend/admin/index.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'index.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="layout-dashboard" class="mr-3 h-6 w-6"></i>
                            Dashboard
                        </a>
                        <a href="/backend/admin/messages.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'messages.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="mail" class="mr-3 h-6 w-6"></i>
                            Messages
                        </a>
                        <a href="/backend/admin/hero.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'hero.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="image" class="mr-3 h-6 w-6"></i>
                            Hero Slider
                        </a>
                        <a href="/backend/admin/about.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'about.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="info" class="mr-3 h-6 w-6"></i>
                            About Section
                        </a>
                        <a href="/backend/admin/events.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'events.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="calendar" class="mr-3 h-6 w-6"></i>
                            Events
                        </a>
                        <a href="/backend/admin/news.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'news.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="newspaper" class="mr-3 h-6 w-6"></i>
                            News
                        </a>
                        <a href="/backend/admin/gallery.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'gallery.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="image-plus" class="mr-3 h-6 w-6"></i>
                            Gallery
                        </a>
                        <a href="/backend/admin/mother_teresa.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'mother_teresa.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="heart" class="mr-3 h-6 w-6"></i>
                            Mother Teresa
                        </a>
                        <a href="/backend/admin/correspondent.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'correspondent.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="user-circle" class="mr-3 h-6 w-6"></i>
                            Correspondent
                        </a>
                        <a href="/backend/admin/transport.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'transport.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="bus" class="mr-3 h-6 w-6"></i>
                            Transport
                        </a>
                        <a href="/backend/admin/testimonials.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'testimonials.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="message-square" class="mr-3 h-6 w-6"></i>
                            Testimonials
                        </a>
                        <a href="/backend/admin/settings.php"
                            class="group flex items-center px-2 py-2 text-sm font-medium rounded-md hover:bg-slate-800 <?php echo strpos($_SERVER['PHP_SELF'], 'settings.php') !== false ? 'bg-slate-800' : ''; ?>">
                            <i data-lucide="settings" class="mr-3 h-6 w-6"></i>
                            Settings
                        </a>
                    </nav>
                </div>
                <div class="flex-shrink-0 flex border-t border-slate-800 p-4">
                    <a href="/backend/auth/logout.php" class="flex-shrink-0 w-full group block">
                        <div class="flex items-center">
                            <i data-lucide="log-out" class="inline-block h-9 w-9 rounded-full text-slate-400"></i>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-white group-hover:text-slate-200">Logout</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex flex-col w-0 flex-1 overflow-hidden">
            <!-- Top bar -->
            <div class="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
                <button onclick="toggleMobileMenu()"
                    class="px-4 border-r border-gray-200 text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500 md:hidden">
                    <i data-lucide="menu" class="h-6 w-6"></i>
                </button>
                <div class="flex-1 px-4 flex justify-between items-center">
                    <div class="flex-1 flex items-center">
                        <h2 class="text-lg md:text-2xl font-semibold text-gray-800">School CMS</h2>
                    </div>
                    <div class="ml-4 flex items-center md:ml-6 space-x-2 md:space-x-4">
                        <a href="/" target="_blank"
                            class="inline-flex items-center px-3 py-1 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            <i data-lucide="external-link" class="h-4 w-4 md:mr-2"></i>
                            <span class="hidden md:inline">Visit Website</span>
                        </a>
                        <span class="text-xs md:text-sm text-gray-600 hidden sm:inline">Welcome, Admin</span>
                    </div>
                </div>
            </div>

            <main class="flex-1 relative overflow-y-auto focus:outline-none bg-gray-100 pb-32 md:pb-24">
                <div class="py-4 md:py-6">