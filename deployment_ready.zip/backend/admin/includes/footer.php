</div>
</main>

<!-- Footer -->
<footer
    class="admin-footer bg-slate-900 text-slate-300 py-4 md:py-6 px-4 md:px-8 border-t border-slate-800 absolute bottom-0 w-full">
    <div class="max-w-7xl mx-auto">
        <div
            class="flex flex-col md:flex-row justify-between items-center space-y-3 md:space-y-0 text-center md:text-left">
            <!-- Left: Branding -->
            <div class="order-2 md:order-1">
                <p class="text-xs md:text-sm font-semibold text-amber-500">Amalan AK International Technologies</p>
                <p class="text-xs text-slate-400 italic hidden md:block">Momentum Beyond Measure</p>
            </div>

            <!-- Center: Links -->
            <div class="order-1 md:order-2 flex flex-col md:flex-row gap-3 md:gap-6 text-xs md:text-sm">
                <a href="https://www.amalanakit.in" target="_blank" rel="noopener noreferrer"
                    class="flex items-center justify-center space-x-1 hover:text-amber-500 transition-colors">
                    <i data-lucide="external-link" class="h-3 w-3 md:h-4 md:w-4"></i>
                    <span>Visit Us</span>
                </a>
                <a href="mailto:backing@amalanakit.in"
                    class="flex items-center justify-center space-x-1 hover:text-amber-500 transition-colors">
                    <i data-lucide="mail" class="h-3 w-3 md:h-4 md:w-4"></i>
                    <span class="hidden sm:inline">backing@amalanakit.in</span>
                    <span class="sm:hidden">Support</span>
                </a>
                <a href="tel:+919791289843"
                    class="flex items-center justify-center space-x-1 hover:text-amber-500 transition-colors">
                    <i data-lucide="phone" class="h-3 w-3 md:h-4 md:w-4"></i>
                    <span class="hidden sm:inline">+91 9791289843</span>
                    <span class="sm:hidden">Call</span>
                </a>
            </div>

            <!-- Right: Copyright -->
            <div class="order-3 hidden md:block">
                <p class="text-xs text-slate-400">
                    © <?php echo date('Y'); ?> All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</footer>
</div>
</div>

<script>
    // Reinitialize Lucide icons for footer and mobile menu
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>
</body>

</html>