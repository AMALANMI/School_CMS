-- Migration: Add testimonials table and section order
-- Run this in your MySQL database

USE school_new_cms;

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    photo_url VARCHAR(255),
    role VARCHAR(255) DEFAULT 'Parent',
    review TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert dummy data
INSERT INTO testimonials (name, photo_url, role, review) VALUES 
('Priya Sharma', NULL, 'Parent of Class 5 Student', 'Excellent school with great focus on holistic development.'),
('Rajesh Kumar', NULL, 'Parent of Class 8 Student', 'The teachers are very supportive and the infrastructure is top-notch.'),
('Anita Desai', NULL, 'Alumni', 'I had the best years of my life here. Highly recommended!');

-- Add to section_order if not exists
INSERT INTO section_order (section_name, display_order, is_visible) 
SELECT 'Testimonials', 8, TRUE 
WHERE NOT EXISTS (SELECT 1 FROM section_order WHERE section_name = 'Testimonials');

-- Verify
SELECT * FROM testimonials;
