<?php
// backend/create_testimonials_table.php
// Run this file once by visiting: http://localhost:8000/backend/create_testimonials_table.php

require_once 'config.php';

echo "<h2>Creating Testimonials Table...</h2>";

// Create testimonials table
$sql = "CREATE TABLE IF NOT EXISTS testimonials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    photo_url VARCHAR(255),
    role VARCHAR(255) DEFAULT 'Parent',
    review TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Testimonials table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating table: " . $conn->error . "</p>";
}

// Insert dummy data
$sql = "INSERT INTO testimonials (name, photo_url, role, review) VALUES 
('Priya Sharma', NULL, 'Parent', 'Excellent school with great focus on holistic development.'),
('Rajesh Kumar', NULL, 'Parent', 'The teachers are very supportive and the infrastructure is top-notch.'),
('Anita Desai', NULL, 'Alumni', 'I had the best years of my life here. Highly recommended!')";

// Only insert if empty
$check = $conn->query("SELECT count(*) as count FROM testimonials");
$row = $check->fetch_assoc();
if ($row['count'] == 0) {
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>✓ Default data inserted!</p>";
    }
}

// Add to section_order
$sql = "INSERT INTO section_order (section_name, display_order, is_visible) 
        SELECT 'Testimonials', 8, TRUE 
        WHERE NOT EXISTS (SELECT 1 FROM section_order WHERE section_name = 'Testimonials')";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Added to Section Order!</p>";
}

echo "<p style='color: green; font-weight: bold;'>✓ Database updated! You can now use the testimonials features.</p>";
echo "<p><a href='/backend/admin/testimonials.php'>Manage Testimonials</a></p>";

$conn->close();

echo "<hr><p style='color: orange;'><strong>IMPORTANT:</strong> Delete this file after running it for security.</p>";
?>