<?php
// backend/create_settings_table.php
// Run this file once by visiting: http://localhost:8000/backend/create_settings_table.php

require_once 'config.php';

echo "<h2>Creating Settings Table...</h2>";

// Create settings table
$sql = "CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY DEFAULT 1,
    
    -- Contact Information
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(100),
    
    -- Map
    map_url TEXT,
    
    -- Branding
    logo_url VARCHAR(255),
    
    -- Social Media Links
    facebook_url VARCHAR(255),
    twitter_url VARCHAR(255),
    instagram_url VARCHAR(255),
    linkedin_url VARCHAR(255),
    youtube_url VARCHAR(255),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Settings table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating table: " . $conn->error . "</p>";
    exit;
}

// Insert default settings
$sql = "INSERT IGNORE INTO settings (
    id, 
    address, 
    phone, 
    email, 
    map_url,
    logo_url,
    facebook_url,
    twitter_url,
    instagram_url,
    linkedin_url,
    youtube_url
) VALUES (
    1,
    '123 Education Avenue, School District, Coimbatore, Tamil Nadu 641001',
    '+91 98765 43210',
    'info@littleflowerschool.edu.in',
    'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.331309838321!2d76.95540331533471!3d11.016844492160677!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba859af2f971cb5%3A0x2fc1c81e183ed282!2sCoimbatore%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1683908856230!5m2!1sen!2sin',
    NULL,
    '#',
    '#',
    '#',
    '#',
    '#'
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Default settings inserted successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error inserting defaults: " . $conn->error . "</p>";
}

// Verify
$result = $conn->query("SELECT * FROM settings WHERE id = 1");
if ($result && $result->num_rows > 0) {
    $settings = $result->fetch_assoc();
    echo "<h3>Settings Table Content:</h3>";
    echo "<pre>" . print_r($settings, true) . "</pre>";
    echo "<p style='color: green; font-weight: bold;'>✓ All done! You can now access the settings page.</p>";
    echo "<p><a href='/backend/admin/settings.php'>Go to Settings Page</a></p>";
} else {
    echo "<p style='color: red;'>✗ Could not verify settings table</p>";
}

$conn->close();

echo "<hr><p style='color: orange;'><strong>IMPORTANT:</strong> Delete this file (create_settings_table.php) after running it for security.</p>";
?>