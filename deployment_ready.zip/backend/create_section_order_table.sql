-- Migration: Add section_order table
-- Run this in your MySQL database

USE school_new_cms;

-- Create section_order table
CREATE TABLE IF NOT EXISTS section_order (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_name VARCHAR(50) UNIQUE NOT NULL,
    display_order INT NOT NULL,
    is_visible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default section order
INSERT INTO section_order (section_name, display_order, is_visible) VALUES
('Hero', 1, TRUE),
('About', 2, TRUE),
('Correspondent', 3, TRUE),
('Transport', 4, TRUE),
('Academics', 5, TRUE),
('Events', 6, TRUE),
('Gallery', 7, TRUE),
('News', 8, TRUE),
('Contact', 9, TRUE)
ON DUPLICATE KEY UPDATE section_name=section_name;

-- Verify
SELECT * FROM section_order ORDER BY display_order;
