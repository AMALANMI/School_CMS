-- Migration: Add correspondent and transport tables
-- Run this in your MySQL database

USE school_new_cms;

-- Create correspondent table
CREATE TABLE IF NOT EXISTS correspondent (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    designation VARCHAR(255),
    photo_url VARCHAR(255),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default correspondent data
INSERT INTO correspondent (id, name, designation, photo_url, message) VALUES (
    1,
    'Dr. John Doe',
    'School Correspondent',
    NULL,
    'Welcome to Little Flower Matriculation School. We are committed to providing quality education and nurturing young minds to become responsible citizens of tomorrow.'
) ON DUPLICATE KEY UPDATE id=id;

-- Create transport table
CREATE TABLE IF NOT EXISTS transport (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255),
    vehicle_photo_url VARCHAR(255),
    description TEXT,
    features TEXT, -- JSON array of features
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default transport data
INSERT INTO transport (id, title, vehicle_photo_url, description, features) VALUES (
    1,
    'Safe & Reliable School Transport',
    NULL,
    'Our school provides safe and comfortable transportation services for students across the city.',
    '["GPS Tracking System","CCTV Cameras in all vehicles","Trained and verified drivers","First Aid Kit","Fire Extinguisher","Regular vehicle maintenance","Female attendant in every bus","Speed governors installed"]'
) ON DUPLICATE KEY UPDATE id=id;

-- Verify tables
SELECT * FROM correspondent;
SELECT * FROM transport;
