<?php
// backend/diagnose_db.php

echo "Starting Database Connection Diagnostics...\n";
echo "-----------------------------------------\n";

$user = 'root';
$pass = ''; // Default
$dbname = 'school_new_cms';

$tests = [
    ['host' => '127.0.0.1', 'label' => 'TCP/IP (127.0.0.1)'],
    ['host' => 'localhost', 'label' => 'Unix Socket (localhost)'],
];

foreach ($tests as $test) {
    echo "Testing {$test['label']}...\n";
    try {
        // Suppress warnings to catch them as exceptions if needed, but mysqli emits warnings too
        $conn = new mysqli($test['host'], $user, $pass, $dbname);

        if ($conn->connect_error) {
            echo "FAIL: " . $conn->connect_error . "\n";
        } else {
            echo "SUCCESS! Connected via " . $test['host'] . "\n";
            echo "Host info: " . $conn->host_info . "\n";
            $conn->close();
            // We found a working one? great.
        }
    } catch (Throwable $e) {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
    echo "-----------------------------------------\n";
}

// Check for common socket locations if on Linux
if (PHP_OS_FAMILY === 'Linux') {
    echo "Checking for common socket files:\n";
    $sockets = [
        '/var/run/mysqld/mysqld.sock',
        '/tmp/mysql.sock',
        '/var/lib/mysql/mysql.sock',
        '/opt/lampp/var/mysql/mysql.sock'
    ];

    foreach ($sockets as $socket) {
        if (file_exists($socket)) {
            echo "FOUND Socket: $socket\n";
        } else {
            echo "MISSING Socket: $socket\n";
        }
    }
}
?>