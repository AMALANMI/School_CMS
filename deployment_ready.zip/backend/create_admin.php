<?php
// backend/create_admin.php
require_once 'config.php';

echo "<h1>CMS Setup & Diagnostics</h1>";

// 1. Check Database Config
echo "<p>Connected to database: <strong>" . DB_NAME . "</strong></p>";

// 2. Check if tables exist
$table_check = $conn->query("SHOW TABLES LIKE 'users'");
if ($table_check->num_rows == 0) {
    echo "<p style='color:orange'>Tables not found. Attempting to create tables from db.sql...</p>";

    $sql_file = __DIR__ . '/db.sql';
    if (file_exists($sql_file)) {
        $sql_content = file_get_contents($sql_file);

        // Remove comments and split by semicolon
        // Note: Simple split might fail on complex stored procedures but fine for this schema
        $queries = explode(';', $sql_content);

        $success = true;
        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!$conn->query($query)) {
                    // Ignore "database exists" or "table exists" errors during this bulk run
                    if (strpos($conn->error, 'exists') === false) {
                        echo "<p style='color:red'>Error executing query: " . htmlspecialchars(substr($query, 0, 50)) . "... - " . $conn->error . "</p>";
                        $success = false;
                    }
                }
            }
        }

        if ($success) {
            echo "<p style='color:green'>Tables created successfully!</p>";
        }
    } else {
        echo "<p style='color:red'>Error: db.sql file not found!</p>";
    }
} else {
    echo "<p style='color:green'>Tables already exist.</p>";
}

// 3. Create/Update Admin User
$username = 'admin';
$password = 'admin123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if admin exists
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update password just in case
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
    $stmt->bind_param("ss", $hashed_password, $username);
    if ($stmt->execute()) {
        echo "<p style='color:green'>Admin user 'admin' exists. Password reset to 'admin123'.</p>";
    } else {
        echo "<p style='color:red'>Error updating admin password: " . $stmt->error . "</p>";
    }
} else {
    // Create user
    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashed_password);
    if ($stmt->execute()) {
        echo "<p style='color:green'>Admin user created successfully.<br>Username: <strong>$username</strong><br>Password: <strong>$password</strong></p>";
    } else {
        echo "<p style='color:red'>Error creating user: " . $stmt->error . "</p>";
    }
}

$conn->close();

echo "<p><a href='admin/login.php'>Go to Admin Login</a></p>";
?>