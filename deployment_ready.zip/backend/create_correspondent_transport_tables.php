<?php
// backend/create_correspondent_transport_tables.php
// Run this file once by visiting: http://localhost:8000/backend/create_correspondent_transport_tables.php

require_once 'config.php';

echo "<h2>Creating Correspondent and Transport Tables...</h2>";

// Create correspondent table
$sql = "CREATE TABLE IF NOT EXISTS correspondent (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    designation VARCHAR(255),
    photo_url VARCHAR(255),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Correspondent table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating correspondent table: " . $conn->error . "</p>";
}

// Insert default correspondent
$sql = "INSERT INTO correspondent (id, name, designation, photo_url, message) VALUES (
    1,
    'Dr. John Doe',
    'School Correspondent',
    NULL,
    'Welcome to Little Flower Matriculation School. We are committed to providing quality education and nurturing young minds to become responsible citizens of tomorrow.'
) ON DUPLICATE KEY UPDATE id=id";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Default correspondent data inserted!</p>";
}

// Create transport table
$sql = "CREATE TABLE IF NOT EXISTS transport (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255),
    vehicle_photo_url VARCHAR(255),
    description TEXT,
    features TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Transport table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating transport table: " . $conn->error . "</p>";
}

// Insert default transport
$sql = "INSERT INTO transport (id, title, vehicle_photo_url, description, features) VALUES (
    1,
    'Safe & Reliable School Transport',
    NULL,
    'Our school provides safe and comfortable transportation services for students across the city.',
    '[\"GPS Tracking System\",\"CCTV Cameras in all vehicles\",\"Trained and verified drivers\",\"First Aid Kit\",\"Fire Extinguisher\",\"Regular vehicle maintenance\",\"Female attendant in every bus\",\"Speed governors installed\"]'
) ON DUPLICATE KEY UPDATE id=id";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Default transport data inserted!</p>";
}

// Verify
echo "<h3>Correspondent Data:</h3>";
$result = $conn->query("SELECT * FROM correspondent WHERE id = 1");
if ($result && $result->num_rows > 0) {
    echo "<pre>" . print_r($result->fetch_assoc(), true) . "</pre>";
}

echo "<h3>Transport Data:</h3>";
$result = $conn->query("SELECT * FROM transport WHERE id = 1");
if ($result && $result->num_rows > 0) {
    echo "<pre>" . print_r($result->fetch_assoc(), true) . "</pre>";
}

echo "<p style='color: green; font-weight: bold;'>✓ All done! You can now access the admin pages.</p>";
echo "<p><a href='/backend/admin/correspondent.php'>Manage Correspondent</a> | <a href='/backend/admin/transport.php'>Manage Transport</a></p>";

$conn->close();

echo "<hr><p style='color: orange;'><strong>IMPORTANT:</strong> Delete this file after running it for security.</p>";
?>