<?php
// backend/create_contact_tables.php
// Run this file once by visiting: http://localhost:8000/backend/create_contact_tables.php

require_once 'config.php';

echo "<h2>Creating Contact Messages Table & Updating Settings...</h2>";

// Create contact_messages table
$sql = "CREATE TABLE IF NOT EXISTS contact_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(255),
    message TEXT NOT NULL,
    status ENUM('new', 'read', 'replied') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Contact messages table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating table: " . $conn->error . "</p>";
}

// Add whatsapp_number column to settings table
$checkColumn = $conn->query("SHOW COLUMNS FROM settings LIKE 'whatsapp_number'");
if ($checkColumn->num_rows == 0) {
    $sql = "ALTER TABLE settings ADD whatsapp_number VARCHAR(20) DEFAULT NULL";
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>✓ Added whatsapp_number to settings table!</p>";
    } else {
        echo "<p style='color: red;'>✗ Error updating settings table: " . $conn->error . "</p>";
    }
} else {
    echo "<p style='color: blue;'>ℹ whatsapp_number column already exists.</p>";
}

echo "<p style='color: green; font-weight: bold;'>✓ Database updated! You can now use the contact form features.</p>";
echo "<p><a href='/backend/admin/messages.php'>Go to Messages</a></p>";

$conn->close();

echo "<hr><p style='color: orange;'><strong>IMPORTANT:</strong> Delete this file after running it for security.</p>";
?>