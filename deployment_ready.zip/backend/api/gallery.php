<?php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 12;
        $offset = ($page - 1) * $limit;

        $category = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : null;
        $where_clause = "";
        if ($category && $category !== 'All') {
            $where_clause = "WHERE category = '$category'";
        }

        // Count total for pagination
        $count_sql = "SELECT COUNT(*) as total FROM gallery $where_clause";
        $count_result = $conn->query($count_sql);
        $total_rows = $count_result->fetch_assoc()['total'];
        $total_pages = ceil($total_rows / $limit);

        // Fetch images
        $sql = "SELECT * FROM gallery $where_clause ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);

        $images = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $images[] = $row;
            }
        }

        echo json_encode([
            'images' => $images,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $total_pages,
                'total_items' => $total_rows,
                'items_per_page' => $limit
            ]
        ]);
        break;

    case 'POST':
        // Handle image upload and data insertion
// Expecting JSON body for data, but file upload usually needs FormData which is POST but contents are in $_POST and $_FILES
// However, the admin panel uses `upload.php` first to get URL, then sends JSON here.

        // Check if content-type is json
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            // Fallback for FormData if not JSON (though admin uses JSON)
            $title = $_POST['title'] ?? '';
            $category = $_POST['category'] ?? 'General';
            $image_url = $_POST['image_url'] ?? '';
        } else {
            $title = $data['title'] ?? '';
            $category = $data['category'] ?? 'General';
            $image_url = $data['image_url'] ?? '';
        }

        if (empty($image_url)) {
            echo json_encode(['error' => 'Image URL is required']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO gallery (title, category, image_url) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $title, $category, $image_url);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            echo json_encode(['error' => 'Database error: ' . $conn->error]);
        }
        break;

    case 'DELETE':
        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if (!$id) {
            echo json_encode(['error' => 'ID is required']);
            exit;
        }

        // Optional: Delete physical file if needed, but current upload.php might not support it easily without path logic.
// For now just delete DB record.

        $stmt = $conn->prepare("DELETE FROM gallery WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Database error']);
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>