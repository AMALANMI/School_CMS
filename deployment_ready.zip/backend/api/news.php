<?php
// backend/api/news.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM news ORDER BY date DESC, created_at DESC";
        $result = $conn->query($sql);
        $news = [];
        while ($row = $result->fetch_assoc()) {
            $news[] = $row;
        }
        echo json_encode($news);
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);

        $title = $data['title'] ?? '';
        $excerpt = $data['excerpt'] ?? '';
        $content = $data['content'] ?? '';
        $date = $data['date'] ?? date('Y-m-d');
        $image_url = $data['image_url'] ?? '';
        $author = $data['author'] ?? 'Admin';

        if (empty($title)) {
            http_response_code(400);
            echo json_encode(['error' => 'Title is required']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO news (title, excerpt, content, date, image_url, author) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $title, $excerpt, $content, $date, $image_url, $author);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? 0;

        $title = $data['title'] ?? '';
        $excerpt = $data['excerpt'] ?? '';
        $content = $data['content'] ?? '';
        $date = $data['date'] ?? '';
        $image_url = $data['image_url'] ?? '';
        $author = $data['author'] ?? '';

        if (empty($id)) {
            http_response_code(400);
            echo json_encode(['error' => 'ID is required']);
            exit;
        }

        $stmt = $conn->prepare("UPDATE news SET title=?, excerpt=?, content=?, date=?, image_url=?, author=? WHERE id=?");
        $stmt->bind_param("ssssssi", $title, $excerpt, $content, $date, $image_url, $author, $id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? 0;
        if (empty($id)) {
            http_response_code(400);
            echo json_encode(['error' => 'ID is required']);
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM news WHERE id=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>