<?php
// backend/api/mother_teresa.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM mother_teresa_section WHERE id = 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            echo json_encode($result->fetch_assoc());
        } else {
            echo json_encode([
                'title' => 'Mother Teresa',
                'photo_url' => null,
                'proverb' => 'Not all of us can do great things. But we can do small things with great love.',
                'vision_title' => 'Our Vision',
                'vision_text' => 'To create a society of progressive, thinking individuals...',
                'mission_title' => 'Our Mission',
                'mission_text' => 'To provide a learning environment that encourages children...'
            ]);
        }
        break;

    case 'POST':
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            echo json_encode(['error' => 'Invalid JSON']);
            exit;
        }

        $photo_url = $data['photo_url'] ?? null;
        $proverb = $data['proverb'] ?? '';
        $vision_title = $data['vision_title'] ?? 'Our Vision';
        $vision_text = $data['vision_text'] ?? '';
        $mission_title = $data['mission_title'] ?? 'Our Mission';
        $mission_text = $data['mission_text'] ?? '';

        $stmt = $conn->prepare("UPDATE mother_teresa_section SET photo_url = ?, proverb = ?, vision_title = ?, vision_text = ?, mission_title = ?, mission_text = ? WHERE id = 1");
        $stmt->bind_param("ssssss", $photo_url, $proverb, $vision_title, $vision_text, $mission_title, $mission_text);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Database error: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>