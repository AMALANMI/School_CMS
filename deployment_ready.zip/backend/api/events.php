<?php
// backend/api/events.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM events ORDER BY event_date ASC";
        $result = $conn->query($sql);
        $events = [];
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
        echo json_encode($events);
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);

        $title = $data['title'] ?? '';
        $event_date = $data['event_date'] ?? '';
        $location = $data['location'] ?? '';
        $description = $data['description'] ?? '';
        $image_url = $data['image_url'] ?? '';

        if (empty($title) || empty($event_date)) {
            http_response_code(400);
            echo json_encode(['error' => 'Title and Date are required']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO events (title, event_date, location, description, image_url) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $title, $event_date, $location, $description, $image_url);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? 0;

        $title = $data['title'] ?? '';
        $event_date = $data['event_date'] ?? '';
        $location = $data['location'] ?? '';
        $description = $data['description'] ?? '';
        $image_url = $data['image_url'] ?? '';

        if (empty($id)) {
            http_response_code(400);
            echo json_encode(['error' => 'ID is required']);
            exit;
        }

        $stmt = $conn->prepare("UPDATE events SET title=?, event_date=?, location=?, description=?, image_url=? WHERE id=?");
        $stmt->bind_param("sssssi", $title, $event_date, $location, $description, $image_url, $id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? 0;
        if (empty($id)) {
            http_response_code(400);
            echo json_encode(['error' => 'ID is required']);
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM events WHERE id=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>