<?php
// backend/api/section_order.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM section_order ORDER BY display_order";
        $result = $conn->query($sql);

        $sections = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $sections[] = $row;
            }
        }
        echo json_encode($sections);
        break;

    case 'POST':
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || !isset($data['sections'])) {
            echo json_encode(['error' => 'Invalid data']);
            exit;
        }

        // Update all section orders
        $conn->begin_transaction();

        try {
            foreach ($data['sections'] as $section) {
                $stmt = $conn->prepare("UPDATE section_order SET display_order = ?, is_visible = ? WHERE section_name = ?");
                $stmt->bind_param("iis", $section['display_order'], $section['is_visible'], $section['section_name']);
                $stmt->execute();
            }

            $conn->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>