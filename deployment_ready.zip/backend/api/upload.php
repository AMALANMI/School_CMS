<?php
// backend/api/upload.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!isset($_FILES['image'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No image uploaded']);
    exit;
}

$file = $_FILES['image'];
$fileName = $file['name'];
$fileTmpName = $file['tmp_name'];
$fileSize = $file['size'];
$fileError = $file['error'];
$fileMimeType = $file['type'];

// Get file extension
$fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

// Allowed extensions and MIME types
$allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
$allowedMimeTypes = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp'
];

// Maximum file size: 1MB (1048576 bytes)
$maxFileSize = 1048576;

// Validate file extension
if (!in_array($fileExt, $allowedExtensions)) {
    http_response_code(400);
    echo json_encode([
        'error' => 'Invalid file type. Only .jpg, .jpeg, .png, and .webp files are allowed.'
    ]);
    exit;
}

// Validate MIME type
if (!in_array($fileMimeType, $allowedMimeTypes)) {
    http_response_code(400);
    echo json_encode([
        'error' => 'Invalid file format. File must be a valid image (JPEG, PNG, or WebP).'
    ]);
    exit;
}

// Check for upload errors
if ($fileError !== 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Error uploading file. Please try again.']);
    exit;
}

// Validate file size
if ($fileSize > $maxFileSize) {
    $fileSizeMB = round($fileSize / 1048576, 2);
    http_response_code(400);
    echo json_encode([
        'error' => "File is too large ({$fileSizeMB}MB). Maximum allowed size is 1MB."
    ]);
    exit;
}

// Additional validation: Check actual image dimensions and type
$imageInfo = getimagesize($fileTmpName);
if ($imageInfo === false) {
    http_response_code(400);
    echo json_encode(['error' => 'File is not a valid image.']);
    exit;
}

// Generate unique filename
$newFileName = uniqid('', true) . "." . $fileExt;
$uploadDir = '../uploads/';

// Create upload directory if it doesn't exist
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$fileDestination = $uploadDir . $newFileName;

// Move uploaded file
if (move_uploaded_file($fileTmpName, $fileDestination)) {
    // Return the URL path
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $url = "$protocol://$host/backend/uploads/$newFileName";

    echo json_encode([
        'success' => true,
        'url' => $url,
        'filename' => $newFileName,
        'size' => round($fileSize / 1024, 2) . 'KB'
    ]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to save uploaded file. Please check server permissions.']);
}
?>