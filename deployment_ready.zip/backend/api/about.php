<?php
// backend/api/about.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM about_content LIMIT 1";
        $result = $conn->query($sql);
        if ($row = $result->fetch_assoc()) {
            echo json_encode($row);
        } else {
            // Return default structure if empty
            echo json_encode([
                'title' => '',
                'subtitle' => '',
                'content' => '',
                'image_url' => '',
                'stats_students' => '',
                'stats_teachers' => '',
                'stats_classrooms' => '',
                'stats_years' => ''
            ]);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);

        $title = $data['title'] ?? '';
        $subtitle = $data['subtitle'] ?? '';
        $content = $data['content'] ?? '';
        $image_url = $data['image_url'] ?? '';
        $stats_students = $data['stats_students'] ?? '';
        $stats_teachers = $data['stats_teachers'] ?? '';
        $stats_classrooms = $data['stats_classrooms'] ?? '';
        $stats_years = $data['stats_years'] ?? '';

        // Check if record exists
        $check = $conn->query("SELECT id FROM about_content LIMIT 1");

        if ($check->num_rows > 0) {
            $row = $check->fetch_assoc();
            $id = $row['id'];
            $stmt = $conn->prepare("UPDATE about_content SET title=?, subtitle=?, content=?, image_url=?, stats_students=?, stats_teachers=?, stats_classrooms=?, stats_years=? WHERE id=?");
            $stmt->bind_param("ssssssssi", $title, $subtitle, $content, $image_url, $stats_students, $stats_teachers, $stats_classrooms, $stats_years, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO about_content (title, subtitle, content, image_url, stats_students, stats_teachers, stats_classrooms, stats_years) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssss", $title, $subtitle, $content, $image_url, $stats_students, $stats_teachers, $stats_classrooms, $stats_years);
        }

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>