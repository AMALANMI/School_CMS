<?php
// backend/api/transport.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM transport WHERE id = 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $data = $result->fetch_assoc();
            // Decode features JSON
            $data['features'] = json_decode($data['features'], true);
            echo json_encode($data);
        } else {
            echo json_encode([
                'title' => 'Safe & Reliable School Transport',
                'vehicle_photo_url' => null,
                'description' => 'Our school provides safe transportation.',
                'features' => []
            ]);
        }
        break;

    case 'POST':
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            echo json_encode(['error' => 'Invalid JSON']);
            exit;
        }

        $title = $data['title'] ?? '';
        $vehicle_photo_url = $data['vehicle_photo_url'] ?? null;
        $description = $data['description'] ?? '';
        $features = json_encode($data['features'] ?? []);

        $stmt = $conn->prepare("UPDATE transport SET title = ?, vehicle_photo_url = ?, description = ?, features = ? WHERE id = 1");
        $stmt->bind_param("ssss", $title, $vehicle_photo_url, $description, $features);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Database error: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>