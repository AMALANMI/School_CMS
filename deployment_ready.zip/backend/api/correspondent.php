<?php
// backend/api/correspondent.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM correspondent WHERE id = 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            echo json_encode($result->fetch_assoc());
        } else {
            echo json_encode([
                'name' => 'Dr. John Doe',
                'designation' => 'School Correspondent',
                'photo_url' => null,
                'message' => 'Welcome to our school.'
            ]);
        }
        break;

    case 'POST':
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            echo json_encode(['error' => 'Invalid JSON']);
            exit;
        }

        $name = $data['name'] ?? '';
        $designation = $data['designation'] ?? '';
        $photo_url = $data['photo_url'] ?? null;
        $message = $data['message'] ?? '';

        $stmt = $conn->prepare("UPDATE correspondent SET name = ?, designation = ?, photo_url = ?, message = ? WHERE id = 1");
        $stmt->bind_param("ssss", $name, $designation, $photo_url, $message);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Database error: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>