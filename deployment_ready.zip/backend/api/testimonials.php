<?php
// backend/api/testimonials.php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM testimonials ORDER BY created_at DESC";
        $result = $conn->query($sql);

        $testimonials = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $testimonials[] = $row;
            }
        }
        echo json_encode($testimonials);
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            echo json_encode(['error' => 'Invalid JSON']);
            exit;
        }

        // Add New Testimonial
        if (!isset($data['id'])) {
            $stmt = $conn->prepare("INSERT INTO testimonials (name, photo_url, role, review) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $data['name'], $data['photo_url'], $data['role'], $data['review']);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
            } else {
                echo json_encode(['error' => 'Database error: ' . $conn->error]);
            }
        }
        // Update Existing (Uses POST because some clients/servers have issues with PUT body parsing)
        else {
            // Handle Delete
            if (isset($data['action']) && $data['action'] === 'delete') {
                $stmt = $conn->prepare("DELETE FROM testimonials WHERE id = ?");
                $stmt->bind_param("i", $data['id']);
                if ($stmt->execute()) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['error' => 'Database error: ' . $conn->error]);
                }
            }
            // Handle Update
            else {
                $stmt = $conn->prepare("UPDATE testimonials SET name = ?, photo_url = ?, role = ?, review = ? WHERE id = ?");
                $stmt->bind_param("ssssi", $data['name'], $data['photo_url'], $data['role'], $data['review'], $data['id']);

                if ($stmt->execute()) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['error' => 'Database error: ' . $conn->error]);
                }
            }
        }
        break;

    case 'DELETE':
        // Fallback if needed, but we handle via POST with action
        $id = $_GET['id'] ?? null;
        if ($id) {
            $stmt = $conn->prepare("DELETE FROM testimonials WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['error' => 'Database error']);
            }
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>