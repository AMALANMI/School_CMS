<?php
require_once '../config.php';
require_once '../cors.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM settings WHERE id = 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            echo json_encode($result->fetch_assoc());
        } else {
            // Default fallback if not found
            echo json_encode([
                'address' => '123 Education Avenue, School District, Coimbatore, Tamil Nadu 641001',
                'phone' => '+91 98765 43210',
                'email' => 'info@littleflowerschool.edu.in',
                'whatsapp_number' => '',
                'map_url' => 'https://www.google.com/maps/embed?...',
                'logo_url' => null,
                'facebook_url' => '#',
                'twitter_url' => '#',
                'instagram_url' => '#',
                'linkedin_url' => '#',
                'youtube_url' => '#'
            ]);
        }
        break;

    case 'POST':
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            echo json_encode(['error' => 'Invalid JSON']);
            exit;
        }

        $address = $data['address'] ?? '';
        $phone = $data['phone'] ?? '';
        $email = $data['email'] ?? '';
        $whatsapp_number = $data['whatsapp_number'] ?? '';
        $map_url = $data['map_url'] ?? '';
        $logo_url = $data['logo_url'] ?? null;
        $facebook_url = $data['facebook_url'] ?? '#';
        $twitter_url = $data['twitter_url'] ?? '#';
        $instagram_url = $data['instagram_url'] ?? '#';
        $linkedin_url = $data['linkedin_url'] ?? '#';
        $youtube_url = $data['youtube_url'] ?? '#';

        $stmt = $conn->prepare("UPDATE settings SET 
            address = ?, phone = ?, email = ?, whatsapp_number = ?, map_url = ?, logo_url = ?,
            facebook_url = ?, twitter_url = ?, instagram_url = ?, linkedin_url = ?, youtube_url = ? 
            WHERE id = 1");
        $stmt->bind_param(
            "sssssssssss",
            $address,
            $phone,
            $email,
            $whatsapp_number,
            $map_url,
            $logo_url,
            $facebook_url,
            $twitter_url,
            $instagram_url,
            $linkedin_url,
            $youtube_url
        );

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Database error: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

$conn->close();
?>