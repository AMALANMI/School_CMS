<?php
// backend/auth/logout.php
session_start();
session_destroy();
header('Location: /backend/admin/login.php');
exit;
?>