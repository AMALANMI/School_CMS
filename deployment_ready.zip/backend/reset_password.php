<?php
// backend/reset_password.php
require_once 'config.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the new username and password
$username = 'admin';
$password = 'admin123'; // Default password

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if user exists
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update existing user
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
    $stmt->bind_param("ss", $hashed_password, $username);
    if ($stmt->execute()) {
        echo "Password for user '$username' has been updated successfully.<br>";
        echo "New password: $password";
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Create new user
    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashed_password);
    if ($stmt->execute()) {
        echo "User '$username' created successfully.<br>";
        echo "Password: $password";
    } else {
        echo "Error creating user: " . $conn->error;
    }
}

$stmt->close();
$conn->close();
?>