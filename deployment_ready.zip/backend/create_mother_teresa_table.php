<?php
// backend/create_mother_teresa_table.php
// Run this file once by visiting: http://localhost:8000/backend/create_mother_teresa_table.php

require_once 'config.php';

echo "<h2>Creating Mother Teresa Section Table...</h2>";

// Create table
$sql = "CREATE TABLE IF NOT EXISTS mother_teresa_section (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) DEFAULT 'Mother Teresa',
    photo_url VARCHAR(255),
    proverb TEXT,
    vision_title VARCHAR(255) DEFAULT 'Our Vision',
    vision_text TEXT,
    mission_title VARCHAR(255) DEFAULT 'Our Mission',
    mission_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating table: " . $conn->error . "</p>";
}

// Insert default data
$sql = "INSERT INTO mother_teresa_section (id, title, photo_url, proverb, vision_text, mission_text) VALUES (
    1,
    'Mother Teresa',
    NULL,
    'Not all of us can do great things. But we can do small things with great love.',
    'To create a society of progressive, thinking individuals who will contribute to the intellectual development of the global community.',
    'To provide a learning environment that encourages children to bring out the best in themselves and enables their all-round development.'
) ON DUPLICATE KEY UPDATE id=id";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Default data inserted!</p>";
}

// Add to section_order
$sql = "INSERT INTO section_order (section_name, display_order, is_visible) 
        SELECT 'MotherTeresa', 2, TRUE 
        WHERE NOT EXISTS (SELECT 1 FROM section_order WHERE section_name = 'MotherTeresa')";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Added to Section Order!</p>";

    // Attempt to reorder sections to put MotherTeresa after Hero (order 1)
    // We'll move everything >= 2 down by 1, except MotherTeresa itself
    // This is a bit complex in SQL, so we'll just let the user reorder or set it to 2 and let others duplicate order
    // The admin panel reordering will fix any duplicates easily.
}

echo "<p style='color: green; font-weight: bold;'>✓ All done! You can now access the admin page.</p>";
echo "<p><a href='/backend/admin/mother_teresa.php'>Manage Section</a></p>";

$conn->close();

echo "<hr><p style='color: orange;'><strong>IMPORTANT:</strong> Delete this file after running it for security.</p>";
?>