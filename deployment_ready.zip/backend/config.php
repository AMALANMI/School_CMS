<?php
// backend/config.php

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Default XAMPP password is empty
define('DB_NAME', 'school_new_cms');

// Connect to database
$socket = null;
if (file_exists('/opt/lampp/var/mysql/mysql.sock')) {
    $socket = '/opt/lampp/var/mysql/mysql.sock';
} elseif (file_exists('/var/run/mysqld/mysqld.sock')) {
    $socket = '/var/run/mysqld/mysqld.sock';
}

if ($socket) {
    // echo "Using socket: $socket<br>"; // Debug output removed for API compatibility
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, null, $socket);
} else {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
}

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8mb4");
?>