-- Migration: Add mother_teresa_section table
-- Run this in your MySQL database

USE school_new_cms;

-- Create mother_teresa_section table
CREATE TABLE IF NOT EXISTS mother_teresa_section (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) DEFAULT 'Mother Teresa',
    photo_url VARCHAR(255),
    proverb TEXT,
    vision_title VARCHAR(255) DEFAULT 'Our Vision',
    vision_text TEXT,
    mission_title VARCHAR(255) DEFAULT 'Our Mission',
    mission_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default data
INSERT INTO mother_teresa_section (id, title, photo_url, proverb, vision_text, mission_text) VALUES (
    1,
    'Mother Teresa',
    NULL,
    'Not all of us can do great things. But we can do small things with great love.',
    'To create a society of progressive, thinking individuals who will contribute to the intellectual development of the global community.',
    'To provide a learning environment that encourages children to bring out the best in themselves and enables their all-round development.'
) ON DUPLICATE KEY UPDATE id=id;

-- Add to section_order if not exists with a temporary order (user can reorder later, but we want it after Hero)
INSERT INTO section_order (section_name, display_order, is_visible) 
SELECT 'MotherTeresa', 2, TRUE 
WHERE NOT EXISTS (SELECT 1 FROM section_order WHERE section_name = 'MotherTeresa');

-- Shift other sections down to make room if needed (optional, user can reorder in settings)
-- For now, we'll just insert it.

-- Verify
SELECT * FROM mother_teresa_section;
