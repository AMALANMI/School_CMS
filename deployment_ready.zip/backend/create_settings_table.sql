-- Migration: Create settings table
-- Run this in your MySQL database

USE school_new_cms;

-- Create settings table if it doesn't exist
CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY DEFAULT 1,
    
    -- Contact Information
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(100),
    
    -- Map
    map_url TEXT,
    
    -- Branding
    logo_url VARCHAR(255),
    
    -- Social Media Links
    facebook_url VARCHAR(255),
    twitter_url VARCHAR(255),
    instagram_url VARCHAR(255),
    linkedin_url VARCHAR(255),
    youtube_url VARCHAR(255),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default settings (only if table is empty)
INSERT IGNORE INTO settings (
    id, 
    address, 
    phone, 
    email, 
    map_url,
    logo_url,
    facebook_url,
    twitter_url,
    instagram_url,
    linkedin_url,
    youtube_url
) VALUES (
    1,
    '123 Education Avenue, School District, Coimbatore, Tamil Nadu 641001',
    '+91 98765 43210',
    'info@littleflowerschool.edu.in',
    'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.331309838321!2d76.95540331533471!3d11.016844492160677!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba859af2f971cb5%3A0x2fc1c81e183ed282!2sCoimbatore%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1683908856230!5m2!1sen!2sin',
    NULL,
    '#',
    '#',
    '#',
    '#',
    '#'
);

-- Verify the table was created
SELECT * FROM settings;
