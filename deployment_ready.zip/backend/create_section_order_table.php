<?php
// backend/create_section_order_table.php
// Run this file once by visiting: http://localhost:8000/backend/create_section_order_table.php

require_once 'config.php';

echo "<h2>Creating Section Order Table...</h2>";

// Create section_order table
$sql = "CREATE TABLE IF NOT EXISTS section_order (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_name VARCHAR(50) UNIQUE NOT NULL,
    display_order INT NOT NULL,
    is_visible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Section order table created successfully!</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating table: " . $conn->error . "</p>";
}

// Insert default section order
$sections = [
    ['Hero', 1],
    ['About', 2],
    ['Correspondent', 3],
    ['Transport', 4],
    ['Academics', 5],
    ['Events', 6],
    ['Gallery', 7],
    ['News', 8],
    ['Contact', 9]
];

foreach ($sections as $section) {
    $sql = "INSERT INTO section_order (section_name, display_order, is_visible) 
            VALUES (?, ?, TRUE) 
            ON DUPLICATE KEY UPDATE section_name=section_name";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $section[0], $section[1]);
    $stmt->execute();
}

echo "<p style='color: green;'>✓ Default section order inserted!</p>";

// Verify
echo "<h3>Current Section Order:</h3>";
$result = $conn->query("SELECT * FROM section_order ORDER BY display_order");
if ($result && $result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Order</th><th>Section</th><th>Visible</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['display_order'] . "</td>";
        echo "<td>" . $row['section_name'] . "</td>";
        echo "<td>" . ($row['is_visible'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

echo "<p style='color: green; font-weight: bold;'>✓ All done! You can now manage section order in Settings.</p>";
echo "<p><a href='/backend/admin/settings.php'>Go to Settings</a></p>";

$conn->close();

echo "<hr><p style='color: orange;'><strong>IMPORTANT:</strong> Delete this file after running it for security.</p>";
?>