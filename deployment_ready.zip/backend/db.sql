-- Create database if not exists
CREATE DATABASE IF NOT EXISTS school_new_cms;
USE school_new_cms;

-- Users table for admin authentication
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Basic data for default admin (password: admin123)
-- Ideally this should be hashed, but for initial setup we can use a script to hash it or insert it manually
-- INSERT INTO users (username, password) VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Hero Section Slides
CREATE TABLE IF NOT EXISTS hero_slides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    subtitle VARCHAR(255),
    image_url VARCHAR(255) NOT NULL,
    cta_text VARCHAR(50) DEFAULT 'Explore Admissions',
    cta_link VARCHAR(255) DEFAULT '/admissions',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- About Section Content
CREATE TABLE IF NOT EXISTS about_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    subtitle VARCHAR(255),
    content TEXT NOT NULL,
    image_url VARCHAR(255),
    stats_students VARCHAR(50) DEFAULT '1,500+',
    stats_teachers VARCHAR(50) DEFAULT '100+',
    stats_classrooms VARCHAR(50) DEFAULT '45+',
    stats_years VARCHAR(50) DEFAULT '25+',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Academics Section
CREATE TABLE IF NOT EXISTS academics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grade_level VARCHAR(100) NOT NULL, -- e.g., "Kindergarten", "Primary", "High School"
    description TEXT,
    icon VARCHAR(50), -- Lucide icon name or image url
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Events
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    event_date DATETIME NOT NULL,
    location VARCHAR(255),
    description TEXT,
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- News & Updates
CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    excerpt TEXT,
    content TEXT,
    date DATE NOT NULL,
    image_url VARCHAR(255),
    author VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Gallery
CREATE TABLE IF NOT EXISTS gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    category VARCHAR(50) DEFAULT 'General', -- e.g., Campus, Sports, Events
    image_url VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Populate with some initial data for testing
INSERT INTO about_content (title, subtitle, content, image_url) 
VALUES (
    'Little Flower Matric School',
    'About Our Institution',
    'Established with a vision to nurture young minds, Little Flower Matriculation School has been a beacon of academic excellence and holistic development. We believe in providing a nurturing environment where every child can bloom to their fullest potential.',
    'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=800'
);

INSERT INTO hero_slides (title, subtitle, image_url, sort_order) VALUES 
('Welcome to Little Flower Matric School', 'Nurturing Minds, Shaping Futures', 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80', 1),
('Excellence in Academics', 'From Pre-KG to VIII, providing holistic education', 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80', 2),
('Life Arts & Extracurriculars', 'Karate, Silambam, Bharathanatiyam, and more', 'https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80', 3);
