<?php
// install.php - Premium School Website Installer
session_start();

$message = '';
$status = '';
$installed = false;

// Auto-detect protocol and host
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$currentUrl = $protocol . "://" . $host;
$baseDir = dirname($_SERVER['PHP_SELF']);
if ($baseDir === '/' || $baseDir === '\\')
    $baseDir = '';
$defaultSiteUrl = $currentUrl . $baseDir;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $db_host = $_POST['db_host'] ?? 'localhost';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $site_url = rtrim($_POST['site_url'] ?? $defaultSiteUrl, '/');

    if (empty($db_name) || empty($db_user)) {
        $message = "Database Name and Username are required.";
        $status = "error";
    } else {
        // Try connecting
        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            $message = "Database Connection Failed: " . $conn->connect_error;
            $status = "error";
        } else {
            // Connection successful

            // 1. Import Database Logic
            $sqlFile = 'backend/school_setup.sql';
            if (file_exists($sqlFile)) {
                $sqlContent = file_get_contents($sqlFile);

                // Replace development URL with production Site URL
                // The dump contains 'http://localhost:8000' for images
                $devUrl = 'http://localhost:8000';
                $sqlContent = str_replace($devUrl, $site_url, $sqlContent);

                // Execute SQL Dump
                if ($conn->multi_query($sqlContent)) {
                    do {
                        // Store and free results to clear buffer
                        if ($result = $conn->store_result()) {
                            $result->free();
                        }
                    } while ($conn->next_result());

                    // 2. Create config.php
                    $configContent = "<?php\n";
                    $configContent .= "// backend/config.php\n\n";
                    $configContent .= "// Database Configuration\n";
                    $configContent .= "define('DB_HOST', '" . addslashes($db_host) . "');\n";
                    $configContent .= "define('DB_USER', '" . addslashes($db_user) . "');\n";
                    $configContent .= "define('DB_PASS', '" . addslashes($db_pass) . "');\n";
                    $configContent .= "define('DB_NAME', '" . addslashes($db_name) . "');\n\n";
                    $configContent .= "// Connect to database\n";
                    $configContent .= "\$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);\n\n";
                    $configContent .= "// Check connection\n";
                    $configContent .= "if (\$conn->connect_error) {\n";
                    $configContent .= "    die(\"Connection failed: \" . \$conn->connect_error);\n";
                    $configContent .= "}\n\n";
                    $configContent .= "\$conn->set_charset(\"utf8mb4\");\n";
                    $configContent .= "?>";

                    if (file_put_contents('backend/config.php', $configContent)) {
                        $message = "Installation Successful! Your website is ready.";
                        $status = "success";
                        $installed = true;
                    } else {
                        $message = "Database imported, but failed to write backend/config.php. Please check file permissions.";
                        $status = "warning";
                    }

                } else {
                    $message = "Error importing database: " . $conn->error;
                    $status = "error";
                }

            } else {
                $message = "SQL dump file not found at " . $sqlFile;
                $status = "error";
            }
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Premium School Website</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Website Installer
        </h2>
        <p class="mt-2 text-center text-sm text-gray-600">
            Setup your school website in one click
        </p>
    </div>

    <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div class="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">

            <?php if ($installed): ?>
                <div class="rounded-md bg-green-50 p-4 mb-6">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                    clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-green-800">Success!</h3>
                            <div class="mt-2 text-sm text-green-700">
                                <p><?php echo $message; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <a href="/" target="_blank"
                        class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        View Frontend
                    </a>
                    <a href="/backend/admin/" target="_blank"
                        class="w-full flex justify-center py-3 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Admin Login
                    </a>
                </div>

                <div class="mt-6 border-t border-gray-200 pt-4">
                    <p class="text-xs text-red-500 text-center font-medium">
                        IMPORTANT: Please verify your site works, then delete this install.php file for security.
                    </p>
                </div>

            <?php else: ?>

                <?php if ($status === 'error'): ?>
                    <div class="rounded-md bg-red-50 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <svg class="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                    fill="currentColor">
                                    <path fill-rule="evenodd"
                                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                                        clip-rule="evenodd" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-red-800">Installation Error</h3>
                                <div class="mt-2 text-sm text-red-700">
                                    <p><?php echo $message; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <form class="space-y-6" action="" method="POST">

                    <div>
                        <label for="site_url" class="block text-sm font-medium text-gray-700">Site URL</label>
                        <div class="mt-1">
                            <input id="site_url" name="site_url" type="url" required
                                value="<?php echo htmlspecialchars($defaultSiteUrl); ?>"
                                class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <p class="mt-1 text-xs text-gray-500">e.g., https://myschool.com (No trailing slash)</p>
                        </div>
                    </div>

                    <div>
                        <label for="db_host" class="block text-sm font-medium text-gray-700">Database Host</label>
                        <div class="mt-1">
                            <input id="db_host" name="db_host" type="text" required value="localhost"
                                class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                    </div>

                    <div>
                        <label for="db_name" class="block text-sm font-medium text-gray-700">Database Name</label>
                        <div class="mt-1">
                            <input id="db_name" name="db_name" type="text" required
                                class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                placeholder="user_school_db">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label for="db_user" class="block text-sm font-medium text-gray-700">DB Username</label>
                            <div class="mt-1">
                                <input id="db_user" name="db_user" type="text" required
                                    class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                    placeholder="user_admin">
                            </div>
                        </div>

                        <div>
                            <label for="db_pass" class="block text-sm font-medium text-gray-700">DB Password</label>
                            <div class="mt-1">
                                <input id="db_pass" name="db_pass" type="password"
                                    class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <button type="submit"
                            class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            Install Website
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>